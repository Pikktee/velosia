/*
 * Velosia Autofill Engine — shared single source of truth
 * ---------------------------------------------------------
 * Pure DOM JavaScript (no chrome.* APIs, no platform globals) so the exact same
 * file can run in two very different hosts:
 *
 *   1. Chrome/Firefox extension  -> loaded as a content script before content.js.
 *   2. Android WebView shell      -> bundled as an asset and injected via
 *                                    WebView.evaluateJavascript().
 *
 * The host is responsible for authentication, fetching the draft JSON and (for the
 * extension) handing over the resolved image URLs / backend base url. The engine
 * only touches the DOM of the target page (Vinted / Kleinanzeigen).
 *
 * Public API:
 *   window.__velosia.autofill(draft, options) -> Promise<result>
 *
 *   options = {
 *     platform:   "vinted" | "kleinanzeigen" | "ebay" | null  (null = auto-detect)
 *     autoSubmit: boolean   (default false -> user reviews & clicks publish himself)
 *     userZip:    string    (Kleinanzeigen postcode, optional)
 *     userCity:   string    (optional)
 *     backendUrl: string    (used to resolve relative image paths, extension only)
 *     imageMode:  "datatransfer" | "native"  (datatransfer = engine fetches & injects
 *                  the files itself; native = engine only clicks the <input type=file>
 *                  so the Android host can supply the photo via onShowFileChooser)
 *     showOverlay: boolean  (default true -> visible "what was filled" panel)
 *     onPublishIntent:   fn({platform, draftId, source})  (optional host hook: the
 *                  user / auto-submit triggered the publish action — the extension
 *                  arms its listing-capture marker only then)
 *     onListingCaptured: fn({platform, listingId, listingUrl})  (optional: the Vinted
 *                  watcher captured the published item)
 *     onCaptureAborted:  fn({platform, reason})  (optional: the Vinted watcher gave up,
 *                  e.g. the user left the form without publishing)
 *   }
 *
 *   result = { platform, phase, filled:[], manual:[], photos:Number, submitted:Bool }
 */
(function () {
  "use strict";

  // Re-injection guard. On Android the script may be injected on every page load,
  // and in the extension it is a persistent content script — never redefine.
  if (window.__velosia && window.__velosia.__loaded) return;

  var VERSION = "2.8.14";
  var KA_TITLE_MAX = 65;

  // Cut at the last word boundary within `max`; hard cut if that loses too much.
  function clampTitle(title, max) {
    var t = String(title || "").replace(/\s+/g, " ").trim();
    if (t.length <= max) return t;
    var cut = t.slice(0, max + 1);
    var sp = cut.lastIndexOf(" ");
    cut = sp >= max / 2 ? cut.slice(0, sp) : t.slice(0, max);
    return cut.replace(/[\s,;:\-–(\/]+$/, "");
  }

  // ----------------------------------------------------------------------------
  // Low level helpers
  // ----------------------------------------------------------------------------

  function norm(s) {
    return (s == null ? "" : String(s))
      .toLowerCase()
      .replace(/[^a-z0-9äöüß]+/g, " ")
      .trim();
  }

  function sleep(ms) {
    return new Promise(function (r) { setTimeout(r, ms); });
  }

  function isInteractable(el) {
    if (!el) return false;
    if (el.disabled) return false;
    if (el.type === "hidden") return false;
    if (el.getAttribute && el.getAttribute("aria-hidden") === "true") return false;
    var style = window.getComputedStyle(el);
    if (!style) return true;
    if (style.display === "none" || style.visibility === "hidden") return false;
    return true;
  }

  /*
   * React/Vue store the "real" value in their own state and overwrite the input's
   * value setter. A plain `el.value = x` updates the visible DOM node but is wiped
   * on the next render / lost on submit. We must call the *native* prototype setter
   * and then dispatch a bubbling input event so the framework picks the change up.
   * This is THE fix that makes Vinted (a React SPA) actually work.
   */
  function setNativeValue(el, value) {
    var ownDesc = Object.getOwnPropertyDescriptor(el, "value");
    var proto = Object.getPrototypeOf(el);
    var protoDesc = Object.getOwnPropertyDescriptor(proto, "value");
    var ownSetter = ownDesc && ownDesc.set;
    var protoSetter = protoDesc && protoDesc.set;

    if (protoSetter && ownSetter !== protoSetter) {
      protoSetter.call(el, value);
    } else if (ownSetter) {
      ownSetter.call(el, value);
    } else {
      el.value = value;
    }
  }

  function fillField(el, value) {
    if (!el) return false;
    if (value === undefined || value === null || value === "") return false;
    try { el.focus(); } catch (e) {}
    setNativeValue(el, String(value));
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    try { el.setAttribute("data-velosia-filled", "1"); } catch (e) {}
    return true;
  }

  // ----------------------------------------------------------------------------
  // Field discovery — try multiple strategies, prefer interactable elements
  // ----------------------------------------------------------------------------

  function pickFromSelector(selector) {
    var els;
    try { els = document.querySelectorAll(selector); } catch (e) { return null; }
    for (var i = 0; i < els.length; i++) {
      if (isInteractable(els[i])) return els[i];
    }
    return null;
  }

  function firstBySelectors(selectors) {
    for (var i = 0; i < selectors.length; i++) {
      var el = pickFromSelector(selectors[i]);
      if (el) return el;
    }
    return null;
  }

  // Collect label-ish text describing a control (label[for], wrapping label/legend,
  // aria-label, name, placeholder). Used both for fallback matching and attributes.
  function labelTextFor(el) {
    var txt = "";
    if (el.id) {
      var lab = document.querySelector("label[for='" + el.id + "']");
      if (lab) txt += " " + lab.textContent;
    }
    txt += " " + (el.getAttribute("aria-label") || "");
    txt += " " + (el.getAttribute("name") || "");
    txt += " " + (el.getAttribute("placeholder") || "");
    var node = el.parentElement, depth = 0;
    while (node && depth < 4) {
      if (node.tagName === "LABEL" || node.tagName === "LEGEND") txt += " " + node.textContent;
      var inner = node.querySelector ? node.querySelector("label, legend") : null;
      if (inner) txt += " " + inner.textContent;
      node = node.parentElement; depth++;
    }
    return norm(txt);
  }

  // Fallback: scan all controls of the given tags and match their label text.
  function findByLabel(needles, tags) {
    var sel = tags.join(",");
    var fields = document.querySelectorAll(sel);
    for (var i = 0; i < fields.length; i++) {
      var el = fields[i];
      if (!isInteractable(el)) continue;
      var txt = labelTextFor(el);
      for (var j = 0; j < needles.length; j++) {
        if (txt.indexOf(needles[j]) !== -1) return el;
      }
    }
    return null;
  }

  function findField(spec) {
    return firstBySelectors(spec.selectors) ||
           (spec.labels ? findByLabel(spec.labels, spec.tags || ["input", "textarea"]) : null);
  }

  // ----------------------------------------------------------------------------
  // Platform / phase detection
  // ----------------------------------------------------------------------------

  function ebayIsNewListingForm() {
    try {
      var q = new URLSearchParams(window.location.search || "");
      var mode = q.get("mode");
      return (!mode || mode === "AddItem") && !q.get("itemId");
    } catch (e) { return false; }
  }

  function detectPlatform() {
    var h = window.location.hostname || "";
    if (h.indexOf("kleinanzeigen") !== -1) return "kleinanzeigen";
    if (h.indexOf("vinted") !== -1) return "vinted";
    if (/(^|\.)ebay\.de$/.test(h)) return "ebay";
    return null;
  }

  // Kleinanzeigen is a two-step flow: step 1 picks a category from a hierarchical
  // tree (hash-routed), step 2 is the real form. Vinted has a single form page.
  function detectPhase(platform) {
    var p = window.location.pathname || "";
    if (platform === "kleinanzeigen") {
      if (p.indexOf("p-anzeige-aufgeben-schritt2") !== -1) return "form";
      if (p.indexOf("p-anzeige-aufgeben") !== -1) return "category";
      return "form";
    }
    if (platform === "ebay") {
      if (p.indexOf("/sh/lst/drafts") === 0) return "drafts";
      if (p.indexOf("/sl/prelist/identify") === 0) return "identify";
      if (p.indexOf("/sl/prelist") === 0 || p.indexOf("/sl/sell") === 0) return "prelist";
      // /lstng also serves "Angebot überarbeiten" / "Ähnlichen Artikel verkaufen"
      // (mode=ReviseItem…, itemId=…) — never a Velosia draft's target.
      if (!ebayIsNewListingForm()) return "other";
      return "form";
    }
    return "form";
  }

  // ----------------------------------------------------------------------------
  // Field maps per platform. Order matters: most reliable selector first, then
  // looser fallbacks, then label-text matching.
  // ----------------------------------------------------------------------------

  var FIELD_MAP = {
    vinted: {
      // Verified against the live vinted.de "items/new" form (data-testid is the
      // most stable handle; #id and name are equivalent fallbacks).
      title: {
        selectors: ["input[data-testid='title--input']", "#title", "input[name='title']", "input[placeholder*='verkaufst']"],
        labels: ["titel", "title"], tags: ["input"]
      },
      description: {
        selectors: ["textarea[data-testid='description--input']", "#description", "textarea[name='description']", "textarea[placeholder*='darüber']"],
        labels: ["beschreib", "description"], tags: ["textarea"]
      },
      price: {
        selectors: ["input[data-testid='price-input--input']", "#price", "input[name='price']", "input[placeholder*='0,00']"],
        labels: ["preis", "price"], tags: ["input"]
      }
    },
    kleinanzeigen: {
      // Verified against the live p-anzeige-aufgeben-schritt2 form. The form now
      // uses #ad-* ids and name="priceAmount"/"zipCode"; the old #postad-*/#pstad-*
      // ids are kept only as trailing fallbacks for older layouts.
      title: {
        selectors: ["#ad-title", "input[name='title']", "#postad-title", "input[id*='title']"],
        labels: ["titel", "überschrift", "uberschrift"], tags: ["input"]
      },
      description: {
        selectors: ["#ad-description", "textarea[name='description']", "#pstad-descrptn", "textarea[id*='descr']"],
        labels: ["beschreib"], tags: ["textarea"]
      },
      price: {
        selectors: ["#ad-price-amount", "input[name='priceAmount']", "#pstad-price", "input[id*='price']"],
        labels: ["preis"], tags: ["input"]
      }
    },
    ebay: {
      // /lstng (live 2026-11). The description textarea is hidden behind the
      // rich-text editor — filled separately (ebaySetDescription).
      title: { selectors: ["input[name='title']"], labels: ["angebotstitel"], tags: ["input"] },
      description: { selectors: ["textarea[name='description']"] },
      price: { selectors: ["input[name='price']"], labels: ["artikelpreis"], tags: ["input"] }
    }
  };

  // ----------------------------------------------------------------------------
  // Images
  // ----------------------------------------------------------------------------

  function resolveImageUrls(draft, backendUrl) {
    var paths = [];
    if (draft.image_paths) {
      var raw = draft.image_paths;
      if (typeof raw === "string") {
        try { raw = JSON.parse(raw); }
        catch (e) {
          // Backend may have stored a Python list repr with single quotes.
          try { raw = JSON.parse(raw.replace(/'/g, '"')); } catch (e2) { raw = null; }
        }
      }
      if (Array.isArray(raw)) paths = raw.filter(Boolean);
    }
    if (paths.length === 0 && draft.image_path) paths = [draft.image_path];
    var base = backendUrl || "";
    return paths.map(function (p) {
      return /^https?:\/\//.test(p) ? p : base + p;
    });
  }

  function findFileInput() {
    var inputs = document.querySelectorAll("input[type='file']");
    for (var i = 0; i < inputs.length; i++) {
      var accept = (inputs[i].accept || "").toLowerCase();
      if (accept === "" || accept.indexOf("image") !== -1) return inputs[i];
    }
    return inputs[0] || null;
  }

  // Poll for the file input — both forms may render it slightly after the core
  // fields. We deliberately do NOT click any "add photo" control to reveal it: on
  // these sites that control opens the native file chooser, which would pop over our
  // backdrop. If no input ever appears we simply leave the photos for a manual add.
  // Be patient: Kleinanzeigen's rebuilt React form (2026) mounts the dropzone input
  // noticeably later than the old layout, and on a slow device the old 2.4 s window
  // was too short — the engine gave up and the listing went up photo-less. ~8 s now.
  async function waitForFileInput() {
    var input = findFileInput();
    for (var i = 0; i < 20 && !input; i++) {
      await sleep(400);
      input = findFileInput();
    }
    return input;
  }

  // Fire a synthetic drop carrying the same files onto the dropzone — for react-dropzone
  // style uploaders (Kleinanzeigen's new form) that ingest via 'drop' rather than the
  // input's 'change'. Verified live: 'change' alone DOES upload on KA, so this is only a
  // fallback (see commitFilesToInput) and never doubles the upload.
  function fireDropEvent(zone, dt) {
    if (!zone) return;
    try {
      var de;
      try { de = new DragEvent("drop", { bubbles: true, cancelable: true, dataTransfer: dt }); }
      catch (e) { de = new Event("drop", { bubbles: true, cancelable: true }); try { de.dataTransfer = dt; } catch (e2) {} }
      zone.dispatchEvent(de);
    } catch (e) {}
  }

  // The photo section around the upload input: climb until the ancestor carries the
  // section heading ("Bilder"/"Fotos"), so previews rendered NEXT to the dropzone count.
  function photoSection(input) {
    var el = input;
    for (var k = 0; k < 8 && el && el.parentElement; k++) {
      el = el.parentElement;
      if (/bilder|fotos/i.test(el.textContent || "") && el.querySelectorAll("*").length > 6) {
        return el.parentElement || el;
      }
    }
    return input.parentElement || document.body;
  }

  // How many photo previews are visible: uploaded KA CDN thumbnails / local blob
  // previews document-wide, plus any <img> inside the photo section.
  function photoPreviewCount(section) {
    var cdn = document.querySelectorAll(
      "img[src*='prod-ads/images'], img[src^='blob:'], img[src^='data:image']"
    ).length;
    var local = section ? section.querySelectorAll("img").length : 0;
    return cdn + local;
  }

  async function waitForPreviewGrowth(section, before, ms) {
    for (var t = 0; t < ms; t += 400) {
      await sleep(400);
      if (photoPreviewCount(section) > before) return true;
    }
    return false;
  }

  // On Kleinanzeigen (allowDrop) the upload is VERIFIED: success only once a preview
  // actually appears. If 'change' produced none, we fire a dropzone 'drop' with the
  // same files and verify again. Returns false when nothing landed, so the overlay
  // honestly asks the user to add the photos instead of claiming success.
  async function commitFilesToInput(input, dt, allowDrop) {
    // eBay: verified against its own counter ("4/25"). Files handed over before
    // its uploader is wired up are dropped silently (seen on the phone when eBay
    // jumped straight into an existing draft), so retry on a freshly found input.
    if (/(^|\.)ebay\.de$/.test(window.location.hostname || "")) {
      var startCount = ebayPhotoCount();
      var target = input;
      for (var attempt = 0; attempt < 3; attempt++) {
        try {
          target.files = dt.files;
          target.dispatchEvent(new Event("input", { bubbles: true }));
          target.dispatchEvent(new Event("change", { bubbles: true }));
        } catch (e) { return false; }
        // Without a readable counter there is nothing to verify — hand over once.
        if (startCount === null) return true;
        // Generous: on a phone several large photos take a while to register.
        for (var t = 0; t < 24; t++) {
          await sleep(500);
          var now = ebayPhotoCount();
          if (now !== null && now > startCount) return true;
        }
        // Retry ONLY when eBay replaced its uploader meanwhile (the documented
        // cause of a silently dropped set). The same input still in place means
        // the upload may just be slow — sending again would double the photos.
        var fresh = findFileInput();
        if (input.isConnected && fresh === input) return true;
        if (!fresh) return false;
        target = input = fresh;
      }
      return false;
    }
    var section = allowDrop ? photoSection(input) : null;
    var before = allowDrop ? photoPreviewCount(section) : 0;
    try {
      input.files = dt.files;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    } catch (e) { return false; }
    if (!allowDrop) return true;

    await sleep(300);
    if (await waitForPreviewGrowth(section, before, 6000)) return true;
    try {
      var zone = input.closest("[class*='dashed'], [class*='drop'], [class*='Drop'], [class*='upload'], [class*='Upload']") || input.parentElement;
      fireDropEvent(zone, dt);
    } catch (e) {}
    if (await waitForPreviewGrowth(section, before, 6000)) return true;
    return false;
  }

  // Fetch each photo and inject ALL of them into the file input via a DataTransfer
  // so the host page's normal upload handler runs. Used by the extension AND by the
  // Android WebView (CORS is "*" on the backend, so the cross-origin fetch of
  // /uploads works) — this uploads every draft photo and needs no user gesture,
  // unlike a programmatic file-chooser click which the WebView blocks.
  async function uploadPhotosDataTransfer(urls, allowDrop) {
    if (urls.length === 0) return 0;
    var input = await waitForFileInput();
    if (!input) return 0;
    var dt = new DataTransfer();
    var count = 0;
    for (var i = 0; i < urls.length; i++) {
      try {
        var resp = await fetch(urls[i]);
        if (!resp.ok) continue;
        var blob = await resp.blob();
        var type = blob.type || "image/jpeg";
        var ext = (type.split("/")[1] || "jpg").replace("jpeg", "jpg");
        var file = new File([blob], "velosia_" + (i + 1) + "." + ext, { type: type });
        dt.items.add(file);
        count++;
      } catch (e) { /* skip individual image failures */ }
    }
    if (count === 0) return 0;
    var ok = await commitFilesToInput(input, dt, allowDrop);
    return ok ? count : 0;
  }

  // Convert a data: URL (base64 or url-encoded) to a File, without any network.
  function dataUrlToFile(dataUrl, baseName) {
    var m = /^data:([^;,]*)(;base64)?,([\s\S]*)$/.exec(dataUrl || "");
    if (!m) return null;
    var type = m[1] || "image/jpeg";
    var isB64 = !!m[2];
    var raw = isB64 ? atob(m[3]) : decodeURIComponent(m[3]);
    var bytes = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    var ext = (type.split("/")[1] || "jpg").replace("jpeg", "jpg");
    return new File([bytes], baseName + "." + ext, { type: type });
  }

  // Android path: the native shell fetches every draft photo with okhttp (no browser
  // CORS) and hands them over as data: URLs through the VelosiaBridge. We build Files
  // from them and inject ALL of them via a DataTransfer — fully CORS-immune.
  async function uploadPhotosFromBridge(allowDrop) {
    var b = (typeof window !== "undefined") ? window.VelosiaBridge : null;
    if (!b || typeof b.getDraftImageCount !== "function") return -1; // bridge not available
    var n = 0;
    try { n = b.getDraftImageCount(); } catch (e) { return -1; }
    if (!n) return 0;
    var input = await waitForFileInput();
    if (!input || typeof DataTransfer === "undefined") return 0;
    var dt = new DataTransfer();
    var count = 0;
    for (var i = 0; i < n; i++) {
      try {
        var du = b.getDraftImageDataUrl(i);
        var f = du ? dataUrlToFile(du, "velosia_" + (i + 1)) : null;
        if (f) { dt.items.add(f); count++; }
      } catch (e) { /* skip individual failures */ }
    }
    if (count === 0) return 0;
    var ok = await commitFilesToInput(input, dt, allowDrop);
    return ok ? count : 0;
  }

  // Native fallback (Android, only if DataTransfer is unavailable): trigger the
  // file chooser; the WebView host intercepts onShowFileChooser and supplies the
  // prepared photo URI. Kept for completeness — the datatransfer path is preferred.
  function triggerNativeFileChooser() {
    var input = findFileInput();
    if (input) { try { input.click(); return 1; } catch (e) {} }
    return 0;
  }

  // ----------------------------------------------------------------------------
  // Kleinanzeigen category picker (step 1: hierarchical category tree)
  // ----------------------------------------------------------------------------
  //
  // The category page (p-anzeige-aufgeben.html) is NOT a keyword search box — it
  // is a hash-routed tree. Each category is encoded in the URL hash, e.g.
  //   #?path=161/176/staubsauger&isParent=undefined
  // Navigating to a valid (leaf) path enables the green "Weiter" button which
  // proceeds to the schritt2 form with the category already filled in.
  //
  // The canonical path comes from the backend catalog via draft.category_path
  // (looked up from the chosen category name). When it is missing we fall back to
  // matching the visible link text; and if even that fails the listing simply
  // stays on the category page for one manual tap — the rest of the form is then
  // filled by the pending-autofill that survives the reload to schritt2.

  function getCategoryPath(draft) {
    var p = draft.category_path || draft.categoryPath || draft.ka_path;
    return (p && String(p).trim()) ? String(p).trim() : null;
  }

  // The primary step button on the category page ("Weiter"). It is disabled until
  // a valid category is selected, so isInteractable() doubles as a readiness gate.
  function findWeiterButton() {
    var cands = document.querySelectorAll(
      "button, a[role='button'], input[type='submit'], a[class*='utton'], a[class*='Button']"
    );
    for (var i = 0; i < cands.length; i++) {
      if (!isInteractable(cands[i])) continue;
      var t = norm(cands[i].innerText || cands[i].value || cands[i].textContent || "");
      if (!t) continue;
      if (t === "weiter" || (t.indexOf("weiter") !== -1 && t.length < 25)) return cands[i];
    }
    return null;
  }

  // Fuzzy text match against the visible category-tree links (fallback only).
  function findCategoryLinkByText(name) {
    var nn = norm(name);
    if (!nn) return null;
    var links = document.querySelectorAll(
      "a.category-selection-list-item-link, .category-selection-list-item a, a[href*='path=']"
    );
    var fuzzy = null;
    for (var i = 0; i < links.length; i++) {
      if (!isInteractable(links[i])) continue;
      var lt = norm(links[i].textContent || "");
      if (!lt) continue;
      if (lt === nn) return links[i];
      if (!fuzzy && (lt.indexOf(nn) !== -1 || nn.indexOf(lt) !== -1)) fuzzy = links[i];
    }
    return fuzzy;
  }

  // Poll for the (now enabled) "Weiter" button and click it to reach schritt2.
  async function proceedFromCategoryPage() {
    for (var i = 0; i < 14; i++) {
      var btn = findWeiterButton();
      if (btn) { try { console.log("Velosia: 'Weiter' gefunden, klicke ->", btn.textContent); btn.click(); return true; } catch (e) {} }
      await sleep(500);
    }
    console.warn("Velosia: kein aktiver 'Weiter'-Button gefunden (Kategorie evtl. nicht gesetzt)");
    return false;
  }

  async function autoSelectCategory(draft) {
    var path = getCategoryPath(draft);

    if (path) {
      // Robust path: jump straight to the category via the hash route, then click
      // "Weiter". A real click on the matching tree link (if rendered) is even more
      // reliable than the bare hash change, so we try that as a reinforcement.
      try { window.location.hash = "?path=" + path + "&isParent=undefined"; } catch (e) {}
      await sleep(900);
      var link = document.querySelector("a.category-selection-list-item-link[href*='path=" + path + "']") ||
                 document.querySelector("a[href*='path=" + path + "']");
      if (link) { try { link.click(); await sleep(700); } catch (e) {} }
      return await proceedFromCategoryPage();
    }

    // Fallback: no known path — match the category name against the visible tree.
    var name = (draft.category || "").trim();
    if (!name) return false;
    for (var t = 0; t < 4; t++) {
      var hit = findCategoryLinkByText(name);
      if (hit) {
        var li = hit.closest ? hit.closest("li") : null;
        var isLeaf = !!(li && li.className && li.className.indexOf("is-leaf") !== -1);
        try { hit.click(); } catch (e) {}
        await sleep(900);
        if (isLeaf) return await proceedFromCategoryPage();
        // Parent expanded — next round may surface the leaf (best effort).
      } else {
        await sleep(600);
      }
    }
    // Maybe a leaf is selected already; try to proceed, else leave it manual.
    return await proceedFromCategoryPage();
  }

  // ----------------------------------------------------------------------------
  // Kleinanzeigen category-specific attributes ("Zusatzfelder")
  // ----------------------------------------------------------------------------

  function parseAttributes(draft) {
    var a = draft.attributes;
    if (!a) return {};
    if (typeof a === "string") {
      try { a = JSON.parse(a); }
      catch (e) { try { a = JSON.parse(a.replace(/'/g, '"')); } catch (e2) { return {}; } }
    }
    return (a && typeof a === "object") ? a : {};
  }

  function pickOption(sel, value) {
    var nv = norm(value);
    if (!nv) return null;
    var i;
    for (i = 0; i < sel.options.length; i++) {
      if (norm(sel.options[i].textContent) === nv) return sel.options[i];
    }
    for (i = 0; i < sel.options.length; i++) {
      var ot = norm(sel.options[i].textContent);
      if (ot && sel.options[i].value && (ot.indexOf(nv) !== -1 || nv.indexOf(ot) !== -1)) return sel.options[i];
    }
    return null;
  }

  function fillAttributes(draft) {
    var attrs = parseAttributes(draft);
    var keys = Object.keys(attrs);
    if (keys.length === 0) return [];

    var filledLabels = [];
    var selects = Array.prototype.slice.call(document.querySelectorAll("select"));
    var texts = Array.prototype.slice.call(document.querySelectorAll("input[type='text'], input:not([type])"));

    keys.forEach(function (key) {
      var label = norm(key);
      var value = attrs[key] == null ? "" : String(attrs[key]);
      if (!label || !value) return;

      // Shipping is usually a checkbox/radio on Kleinanzeigen, not a select.
      if (label.indexOf("versand") !== -1) {
        var wantsShip = norm(value).indexOf("moglich") !== -1 || norm(value).indexOf("versand") !== -1;
        var boxes = document.querySelectorAll("input[type='checkbox'], input[type='radio']");
        var toggled = false;
        for (var b = 0; b < boxes.length; b++) {
          if (labelTextFor(boxes[b]).indexOf("versand") !== -1) {
            if (boxes[b].checked !== wantsShip) boxes[b].click();
            toggled = true;
          }
        }
        if (toggled) { filledLabels.push(key); return; }
      }

      // Try <select> dropdowns first.
      for (var i = 0; i < selects.length; i++) {
        if (selects[i].__velosiaKnown) continue;
        if (labelTextFor(selects[i]).indexOf(label) === -1) continue;
        var opt = pickOption(selects[i], value);
        if (opt) {
          selects[i].value = opt.value;
          selects[i].__velosiaKnown = true;
          selects[i].dispatchEvent(new Event("change", { bubbles: true }));
          filledLabels.push(key);
          return;
        }
      }
      // Then free-text inputs.
      for (var t = 0; t < texts.length; t++) {
        if (texts[t].__velosiaKnown) continue;
        // Skip combobox/autocomplete inputs (e.g. KA's new "Marke" field). Writing raw
        // text into them does NOT commit a real selection — KA reverts it on blur, so
        // the field ends up empty — yet it would mark the field "done" and block the
        // dedicated picker (selectKleinanzeigenBrand). Those are handled separately.
        if (texts[t].getAttribute("role") === "combobox" ||
            texts[t].getAttribute("aria-autocomplete") ||
            texts[t].getAttribute("aria-haspopup") === "listbox") continue;
        if (labelTextFor(texts[t]).indexOf(label) === -1) continue;
        fillField(texts[t], value);
        texts[t].__velosiaKnown = true;
        filledLabels.push(key);
        return;
      }
    });
    return filledLabels;
  }

  // Make sure the listing is an offer ("Ich biete"), not a want ad ("Ich suche").
  function selectKleinanzeigenOffer() {
    var offer = document.querySelector("#ad-type-OFFER") ||
                document.querySelector("input[name='adType'][value='OFFER']");
    if (offer && !offer.checked) {
      offer.click();
    }
  }

  // Kleinanzeigen "Preisart": Festpreis or VB (Verhandlungsbasis). The draft
  // carries the resolved choice (price_type_effective = the draft's own choice or
  // the account preset); without one it stays Festpreis, as before 2.7.57.
  // The control differs between form generations, so radios (old form:
  // name=priceType, value FIXED/NEGOTIABLE), ARIA radios / segmented buttons, a
  // <select> and a labelled listbox picker are all tried — matched by value and by
  // visible text. Returns { found, ok }: ok only when the wanted option ended up
  // selected, found when a price type control exists at all.
  var KA_PRICE_TYPE_WORDS = {
    FIXED: ["festpreis"],
    NEGOTIABLE: ["vb", "verhandlungsbasis"]
  };

  function kaPriceTypeOf(text, value) {
    var v = String(value || "").toUpperCase();
    if (v === "FIXED" || v === "NEGOTIABLE") return v;
    var t = norm(text);
    for (var type in KA_PRICE_TYPE_WORDS) {
      var words = KA_PRICE_TYPE_WORDS[type];
      for (var i = 0; i < words.length; i++) {
        if (t === words[i] || t.indexOf(words[i] + " ") === 0) return type;
      }
    }
    return null;
  }

  function kaRadioLabelText(radio) {
    var lbl = radio.id ? document.querySelector("label[for='" + radio.id + "']") : null;
    return (lbl || radio.closest("label") || {}).textContent || "";
  }

  async function setKleinanzeigenPriceType(type) {
    var found = false;

    // 1) Native radios.
    var radios = document.querySelectorAll("input[type='radio']");
    for (var i = 0; i < radios.length; i++) {
      var r = radios[i];
      var isPriceRadio = /price|preis/i.test(r.name || "") || kaPriceTypeOf(kaRadioLabelText(r), null);
      if (!isPriceRadio) continue;
      var rType = kaPriceTypeOf(kaRadioLabelText(r), r.value);
      if (!rType) continue;
      found = true;
      if (rType !== type) continue;
      if (!r.checked) {
        var rLabel = r.id ? document.querySelector("label[for='" + r.id + "']") : null;
        try { (rLabel || r).click(); } catch (e) {}
        await sleep(150);
      }
      if (!r.checked) {
        r.checked = true;
        r.dispatchEvent(new Event("change", { bubbles: true }));
      }
      return { found: true, ok: r.checked };
    }

    // 2) ARIA radios / toggle buttons ("Festpreis | VB" as a segmented control).
    var toggles = document.querySelectorAll("[role='radio'], button[aria-pressed]");
    for (var j = 0; j < toggles.length; j++) {
      var tEl = toggles[j];
      var tType = kaPriceTypeOf(tEl.textContent, tEl.getAttribute("data-value") || tEl.getAttribute("value"));
      if (!tType || !kaVisible(tEl)) continue;
      found = true;
      if (tType !== type) continue;
      var isOn = function () {
        return tEl.getAttribute("aria-checked") === "true" || tEl.getAttribute("aria-pressed") === "true";
      };
      if (!isOn()) { try { tEl.click(); } catch (e) {} await sleep(150); }
      return { found: true, ok: isOn() };
    }

    // 3) <select> offering both price types.
    var selects = document.querySelectorAll("select");
    for (var k = 0; k < selects.length; k++) {
      var sel = selects[k];
      var want = null, kinds = {};
      for (var o = 0; o < sel.options.length; o++) {
        var oType = kaPriceTypeOf(sel.options[o].textContent, sel.options[o].value);
        if (oType) kinds[oType] = true;
        if (oType === type && !want) want = sel.options[o];
      }
      if (!(kinds.FIXED && kinds.NEGOTIABLE)) continue;
      found = true;
      if (!want) return { found: true, ok: false };
      if (sel.value !== want.value) {
        setNativeValue(sel, want.value);
        sel.dispatchEvent(new Event("input", { bubbles: true }));
        sel.dispatchEvent(new Event("change", { bubbles: true }));
      }
      return { found: true, ok: sel.value === want.value };
    }

    // 4) New-form picker: button#ad-price-type[role=combobox] named "Preistyp" via
    //    aria-labelledby, listbox Festpreis / VB / Zu verschenken, the choice
    //    mirrored into a hidden input[name=priceType] (FIXED / NEGOTIABLE). Live
    //    calibrated 2026-11; a plain click on the option commits it.
    var labels = ["Preistyp", "Preisart", "Art des Preises"];
    var candidates = type === "NEGOTIABLE" ? ["VB", "Verhandlungsbasis"] : ["Festpreis"];
    var control = document.getElementById("ad-price-type");
    var label = null;
    if (!control || !kaVisible(control)) {
      control = null;
      for (var m = 0; m < labels.length && !control; m++) {
        control = kaFieldControl(labels[m]);
        if (control) label = labels[m];
      }
    }
    if (control) {
      found = true;
      if (kaPriceTypeSelected(control) === type) return { found: true, ok: true };
      var opt = await kaOpenAndFind(control, candidates);
      if (opt) {
        try { opt.click(); } catch (e) {}
        await sleep(200);
        if (kaPriceTypeSelected(control) !== type) {
          // Mobile React listboxes may commit on pointerdown only.
          if (control.getAttribute("aria-expanded") !== "true") { try { control.click(); } catch (e) {} await sleep(250); }
          var again = kaSelectFromPool(candidates, false);
          if (again) { kaCommitClick(again); await sleep(250); }
        }
      }
      if (control.getAttribute("aria-expanded") === "true") kaCloseOverlay(control);
      var ok = kaPriceTypeSelected(control) === type;
      try { console.log("Velosia KA: Preistyp " + type + " -> " + (ok ? "gesetzt" : "nicht gesetzt") + (label ? " (" + label + ")" : "")); } catch (e) {}
      return { found: true, ok: ok };
    }

    return { found: found, ok: false };
  }

  // Which price type the new-form picker currently holds: the hidden priceType
  // input first, else the combobox's visible text.
  function kaPriceTypeSelected(control) {
    var hidden = document.querySelector("input[name='priceType']");
    if (hidden && hidden.value) {
      var v = String(hidden.value).toUpperCase();
      if (v === "FIXED" || v === "NEGOTIABLE") return v;
    }
    var shown = document.getElementById("ad-price-type-selected-option");
    return kaPriceTypeOf((shown || control || {}).textContent, null);
  }

  // Open a listbox combobox and wait for an option matching `candidates`.
  async function kaOpenAndFind(control, candidates) {
    try { control.scrollIntoView({ block: "center" }); } catch (e) {}
    if (control.getAttribute("aria-expanded") !== "true") { try { control.click(); } catch (e) {} }
    for (var i = 0; i < 12; i++) {
      await sleep(200);
      var opt = kaSelectFromPool(candidates, false);
      if (opt) return opt;
    }
    return null;
  }

  // Kleinanzeigen "Zustand" — Velosia captures the condition, so set it directly
  // instead of relying on the server having backfilled it into the attributes (which
  // only happens when the category resolved + the AI/validator emitted the field).
  // Maps the free-text condition to KA's fixed option set (Neu / Sehr Gut / Gut /
  // In Ordnung / Defekt). Mirrors the backend CONDITION_TO_ZUSTAND table.
  var KA_CONDITION_MAP = {
    "neu": "Neu",
    "neuwertig": "Sehr Gut",
    "sehr gut": "Sehr Gut",
    "gut": "Gut",
    "zufriedenstellend": "In Ordnung",
    "in ordnung": "In Ordnung",
    "befriedigend": "In Ordnung",
    "defekt": "Defekt"
  };

  // Recognise the Zustand <select> by its OPTION fingerprint (it offers Neu …
  // Defekt) — far more reliable than label matching, which the form often omits.
  function isKleinanzeigenConditionSelect(sel) {
    var hasNeu = false, hasDefekt = false, mid = 0;
    for (var i = 0; i < sel.options.length; i++) {
      var t = norm(sel.options[i].textContent);
      if (t === "neu") hasNeu = true;
      else if (t === "defekt") hasDefekt = true;
      else if (t === "sehr gut" || t === "gut" || t === "in ordnung") mid++;
    }
    return (hasNeu && hasDefekt) || (hasNeu && mid >= 1) || mid >= 2;
  }

  function selectKleinanzeigenCondition(draft) {
    var cond = norm(draft.condition || "");
    if (!cond) return false;
    var target = KA_CONDITION_MAP[cond];
    if (!target) { console.log("Velosia KA: Zustand '" + cond + "' ohne Entsprechung — manuell"); return false; }

    var selects = Array.prototype.slice.call(document.querySelectorAll("select"));
    // Prefer a select whose label mentions "zustand"; else fall back to the fingerprint.
    var sel = null;
    for (var i = 0; i < selects.length; i++) {
      if (selects[i].__velosiaKnown) continue;
      if (labelTextFor(selects[i]).indexOf("zustand") !== -1) { sel = selects[i]; break; }
    }
    if (!sel) {
      for (var j = 0; j < selects.length; j++) {
        if (selects[j].__velosiaKnown) continue;
        if (isKleinanzeigenConditionSelect(selects[j])) { sel = selects[j]; break; }
      }
    }
    if (sel) {
      var opt = pickOption(sel, target);
      if (opt) {
        sel.value = opt.value;
        sel.__velosiaKnown = true;
        sel.dispatchEvent(new Event("change", { bubbles: true }));
        console.log("Velosia KA: Zustand '" + target + "' im Dropdown gesetzt");
        return true;
      }
    }

    // Some categories render Zustand as a row of button/radio "pills" instead.
    var pills = document.querySelectorAll("button, [role='radio'], label, input[type='radio']");
    var nt = norm(target);
    for (var p = 0; p < pills.length; p++) {
      var el = pills[p];
      if (!isInteractable(el)) continue;
      if (el.closest("#velosia-backdrop, #velosia-overlay")) continue;
      if (norm(el.textContent || el.getAttribute("aria-label") || "") === nt) {
        try { el.click(); console.log("Velosia KA: Zustand '" + target + "' per Pill gesetzt"); return true; } catch (e) {}
      }
    }
    console.log("Velosia KA: Zustand-Feld nicht gefunden — manuell");
    return false;
  }

  // --------------------------------------------------------------------------
  // Kleinanzeigen NEW (2026 React form) attribute fields — Zustand / Größe /
  // Farbe / Marke. The <select>/pill paths above no-op on this layout, so we drive
  // the new UI: each field is a <label>Name</label> + a control that opens either a
  // [role=listbox] (click option = immediate) or a modal with radios + a "Bestätigen"
  // button. Options are matched by VISIBLE TEXT, never KA's internal value codes.
  // Verified live: the whole flow (open + select + confirm) runs on synthetic clicks
  // — the earlier "isTrusted gate" reading was a broken detector (KA uses no
  // role=dialog), not a real block.
  // --------------------------------------------------------------------------

  function kaVisible(el) {
    return !!(el && el.offsetParent !== null && !el.closest("#velosia-backdrop, #velosia-overlay"));
  }

  function kaFindVisibleButton(text) {
    var t = norm(text);
    var btns = document.querySelectorAll("button");
    for (var i = 0; i < btns.length; i++) {
      if (kaVisible(btns[i]) && norm(btns[i].textContent) === t) return btns[i];
    }
    return null;
  }

  // Field labels carry category-dependent suffixes: "Zustand (optional)" in
  // Elektronik > PCs vs. plain "Zustand" in fashion, sometimes a required "*".
  // Compare on the bare field name so the pickers find the field either way.
  function kaLabelKey(text) {
    return norm(String(text || "").replace(/\(\s*optional\s*\)/gi, "").replace(/\*/g, ""));
  }

  // The control that opens a field's picker. Most fields expose id === the label's
  // "for"; Zustand's "for" points at an id with no element, so we fall back to the
  // first popup-control inside the field row.
  function kaFieldControl(labelText) {
    var want = norm(labelText);
    var labels = document.querySelectorAll("label");
    for (var i = 0; i < labels.length; i++) {
      if (kaLabelKey(labels[i].textContent) !== want) continue;
      var forId = labels[i].getAttribute("for");
      if (forId) {
        var byId = document.getElementById(forId);
        if (byId && kaVisible(byId)) return byId;
      }
      var row = labels[i];
      for (var k = 0; k < 5 && row.parentElement; k++) {
        row = row.parentElement;
        var ctrl = row.querySelector("button[aria-haspopup='dialog'], [role='combobox'], input[role='combobox']");
        if (ctrl && ctrl !== labels[i] && kaVisible(ctrl)) return ctrl;
      }
    }
    // Some fields have no <label> at all: the field name is a floating <div> the
    // combobox names via aria-labelledby (e.g. "Preistyp": button#ad-price-type,
    // aria-labelledby="ad-price-type-selected-option ad-price-type-label").
    var combos = document.querySelectorAll("[role='combobox'][aria-labelledby]");
    for (var c = 0; c < combos.length; c++) {
      var ids = combos[c].getAttribute("aria-labelledby").split(/\s+/);
      for (var d = 0; d < ids.length; d++) {
        var named = ids[d] && document.getElementById(ids[d]);
        if (named && kaLabelKey(named.textContent) === want && kaVisible(combos[c])) return combos[c];
      }
    }
    return null;
  }

  // Does the form have this attribute field at all? Looser than kaFieldControl (no
  // visibility requirement): a matching <label> or the hidden attributeMap[<cat>.<attr>]
  // input is enough. Used to tell "category has no such field" apart from "picker broke".
  function kaHasField(labelText, hiddenNameRe) {
    var want = norm(labelText);
    var labels = document.querySelectorAll("label");
    for (var i = 0; i < labels.length; i++) {
      if (kaLabelKey(labels[i].textContent) === want) return true;
    }
    if (hiddenNameRe) {
      var named = document.querySelectorAll("input[name^='attributeMap']");
      for (var j = 0; j < named.length; j++) {
        if (hiddenNameRe.test(named[j].name)) return true;
      }
    }
    return false;
  }

  // Visible options of an open picker: listbox options, else (modal pattern) the
  // radio-labels — but only when a "Bestätigen" button is actually on screen.
  function kaOptionPool() {
    var opts = Array.prototype.slice.call(document.querySelectorAll("[role='option']")).filter(kaVisible);
    if (opts.length) return opts;
    if (kaFindVisibleButton("bestätigen")) {
      return Array.prototype.slice.call(document.querySelectorAll("label[for]")).filter(function (l) {
        if (!kaVisible(l)) return false;
        var r = document.getElementById(l.getAttribute("for"));
        return r && r.type === "radio";
      });
    }
    return [];
  }

  // Connector-insensitive key so "Jack & Jones" == "Jack and Jones" == "Jack Jones".
  function kaLooseKey(s) {
    return norm(s).replace(/\b(und|and|the|by)\b/g, " ").replace(/\s+/g, " ").trim();
  }

  // What to TYPE into the brand search to filter: only the part before the first
  // connector (&/+/and/und), because KA's filter is literal — "Jack and Jones" finds
  // nothing, "Jack" finds the superset that contains "Jack & Jones".
  function kaBrandFilterText(brand) {
    var s = String(brand).trim();
    var m = s.match(/^(.*?)\s*(?:&|\+|\band\b|\bund\b)/i);
    var key = (m ? m[1] : s).trim();
    return key.length >= 2 ? key : s;
  }

  // Does an option's text match a wanted value? Handles "M (38)" vs "M" vs "38".
  function kaOptMatches(optText, want, exactOnly) {
    var o = norm(optText), c = norm(want);
    if (!o || !c) return false;
    if (o === c) return true;
    if (exactOnly) return kaLooseKey(optText) === kaLooseKey(want);
    var pre = norm(String(optText).split("(")[0]);
    if (pre && pre === c) return true;
    var m = String(optText).match(/\(([^)]+)\)/);
    if (m && norm(m[1]) === c) return true;
    return (c.length >= 2 && o.length < 30 && o.indexOf(c) !== -1);
  }

  function kaSelectFromPool(candidates, exactOnly) {
    var pool = kaOptionPool();
    for (var c = 0; c < candidates.length; c++) {
      // Exact text first across ALL options — otherwise the substring fallback lets
      // "Sehr Gut" (listed earlier) win for the wanted "Gut".
      for (var x = 0; x < pool.length; x++) {
        if (norm(pool[x].textContent) === norm(candidates[c])) return pool[x];
      }
      for (var i = 0; i < pool.length; i++) {
        if (kaOptMatches(pool[i].textContent, candidates[c], exactOnly)) return pool[i];
      }
    }
    return null;
  }

  function kaCloseOverlay(control) {
    try { document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); } catch (e) {}
    try { if (control) control.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); } catch (e) {}
  }

  // Open one new-form picker and pick the option matching `candidates`. exactOnly is
  // used for Marke (never a wrong brand). Returns true only when an option matched.
  async function selectKleinanzeigenAttribute(labelText, candidates, exactOnly) {
    if (!candidates || !candidates.length) return false;
    var control = kaFieldControl(labelText);
    if (!control) return false;
    try { control.scrollIntoView({ block: "center" }); } catch (e) {}
    try { control.click(); } catch (e) {}
    if (control.tagName === "INPUT") { try { control.focus(); } catch (e) {} }

    var opt = null;
    for (var i = 0; i < 12 && !opt; i++) {
      await sleep(200);
      opt = kaSelectFromPool(candidates, exactOnly);
    }
    if (!opt) { kaCloseOverlay(control); return false; }

    var radioId = (opt.tagName === "LABEL") ? opt.getAttribute("for") : null;
    var radio = radioId ? document.getElementById(radioId) : null;
    try { (radio || opt).click(); } catch (e) {}
    await sleep(200);
    // Modal pattern: commit with "Bestätigen". Listbox pattern: nothing to confirm.
    var confirm = kaFindVisibleButton("bestätigen");
    if (confirm) { try { confirm.click(); } catch (e) {} await sleep(200); }
    try { console.log("Velosia KA: '" + labelText + "' gesetzt (" + norm(opt.textContent).slice(0, 24) + ")"); } catch (e) {}
    return true;
  }

  // After opening the Marke control, find the input that actually filters. Desktop:
  // the control itself. Mobile: KA (like Vinted) may pop a SEARCH MODAL with its own
  // autofocused input — so prefer the focused/visible search input in an open overlay.
  function pickBrandSearchInput(control) {
    var ae = document.activeElement;
    if (ae && ae.tagName === "INPUT" && kaVisible(ae)) return ae;
    var inputs = document.querySelectorAll("input[type='text'], input[type='search'], input[role='combobox'], input:not([type])");
    for (var i = 0; i < inputs.length; i++) {
      if (!kaVisible(inputs[i])) continue;
      if (inputs[i].closest("[role='dialog'], [class*='odal'], [class*='verlay'], [class*='ottomSheet'], [class*='heet'], [class*='earch']")) return inputs[i];
    }
    return (control.tagName === "INPUT") ? control : null;
  }

  // Fire a full pointer+mouse+click sequence on an option. KA's brand combobox (like
  // many React autocompletes) commits the selection on pointerdown/mousedown — NOT a
  // bare .click() (which would arrive only after the input blur already closed the
  // list). So on mobile opt.click() "succeeds" yet the field stays empty; dispatching
  // the whole sequence is what actually commits the pick.
  function kaCommitClick(el) {
    var o = { bubbles: true, cancelable: true, view: window };
    ["pointerover", "pointerenter", "pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(function (t) {
      try {
        var Ctor = (t.indexOf("pointer") === 0 && window.PointerEvent) ? PointerEvent : MouseEvent;
        el.dispatchEvent(new Ctor(t, o));
      } catch (e) { try { el.dispatchEvent(new Event(t, { bubbles: true })); } catch (e2) {} }
    });
    try { el.click(); } catch (e) {}
  }

  // Did the brand actually land? After a real commit KA fills the visible combobox with
  // the full brand text AND writes the hidden attributeMap[...brand] input — either is a
  // reliable signal (typing the filter only ever set the control to the prefix). Lets us
  // report honest success/failure instead of trusting that a click did anything.
  function kaBrandCommitted(brand, control) {
    // STRICT: the combobox's own displayed value must equal the full brand. The earlier
    // "any brand-named input is non-empty" heuristic false-positived on the typed filter
    // prefix ("Jack"), so the engine wrongly reported success while the field was empty.
    return !!(control && kaLooseKey(control.value || "") === kaLooseKey(brand));
  }

  // Type the brand to FILTER the (huge) brand listbox, then click the exact
  // (connector-insensitive) match. KA only filters on a real InputEvent — a plain
  // Event("input") does NOT — and we also fire key events for keyup-based filters.
  // Filtering dodges the full-list render that on mobile left the brand unmatched.
  // Never commits a non-exact brand.
  async function selectKleinanzeigenBrand(brand) {
    // Uniform failure result; reason tells us where the brand step bailed:
    // no control / no input / no matching option / clicked but not committed.
    function bail(reason, extra) {
      var detail = extra ? Object.keys(extra).map(function (k) { return k + "=" + extra[k]; }).join(" ") : "";
      return { ok: false, reason: reason, detail: detail };
    }
    if (!brand) return bail("no_brand_value");
    var control = kaFieldControl("Marke");
    if (!control) return bail("no_control");
    try { control.scrollIntoView({ block: "center" }); } catch (e) {}
    try { control.click(); } catch (e) {}
    await sleep(350);
    var input = pickBrandSearchInput(control);
    if (!input) { kaCloseOverlay(control); return bail("no_input", { activeTag: (document.activeElement || {}).tagName || null }); }
    try { input.focus(); } catch (e) {}
    // Type only the part BEFORE the first connector: KA's own filter is literal and
    // does NOT treat "and" == "&" (typing "Jack and Jones" filters to nothing), so we
    // type "Jack", get the superset, and exact-match the full brand in the results.
    var filterText = kaBrandFilterText(brand);
    var last = filterText.slice(-1);
    try { input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: last })); } catch (e) {}
    setNativeValue(input, filterText);
    try { input.dispatchEvent(new InputEvent("input", { bubbles: true, data: filterText, inputType: "insertText" })); }
    catch (e) { input.dispatchEvent(new Event("input", { bubbles: true })); }
    try { input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: last })); } catch (e) {}

    var want = kaLooseKey(brand);
    var opt = null, lastCount = 0;
    for (var i = 0; i < 25 && !opt; i++) {
      await sleep(200);
      var pool = Array.prototype.slice.call(document.querySelectorAll("[role='option']")).filter(kaVisible);
      lastCount = pool.length;
      for (var j = 0; j < pool.length; j++) {
        if (kaLooseKey(pool[j].textContent) === want) { opt = pool[j]; break; }
      }
    }
    if (!opt) {
      kaCloseOverlay(control);
      return bail("no_match", { optionCount: lastCount,
        typedInto: input === control ? "control" : "overlay-input",
        activeTag: (document.activeElement || {}).tagName || null,
        inputVal: (input.value || "").slice(0, 20) });
    }
    // Commit via the full pointer/mouse sequence (mobile needs pointerdown/mousedown),
    // then VERIFY the field really changed — only then report success. Retry on an inner
    // element and the wrapping <li> in case the React handler sits there.
    kaCommitClick(opt);
    await sleep(250);
    if (!kaBrandCommitted(brand, control)) {
      var inner = opt.querySelector && opt.querySelector("[role='option'], button, a, [class*='ell'], span, div");
      if (inner) { kaCommitClick(inner); await sleep(250); }
    }
    if (!kaBrandCommitted(brand, control)) {
      var li = opt.closest && opt.closest("li");
      if (li && li !== opt) { kaCommitClick(li); await sleep(250); }
    }
    var committed = kaBrandCommitted(brand, control);
    if (committed) {
      // Drop focus so the brand field isn't left active/highlighted after the fill
      // (cosmetic). Safe now that the value is verified committed — blurring only ever
      // discards UNcommitted combobox text, which we've already passed.
      try { if (control && control.blur) control.blur(); } catch (e) {}
      try { var ae = document.activeElement; if (ae && ae.blur) ae.blur(); } catch (e) {}
      try { console.log("Velosia KA: Marke '" + brand + "' gesetzt (gefiltert)"); } catch (e) {}
      return { ok: true };
    }
    // Clicked the right option but KA didn't commit it — return failure (brand stays
    // manual) rather than a false "Alles ausgefüllt".
    return bail("clicked_no_commit", { optText: norm(opt.textContent).slice(0, 18), ctrlVal: (control.value || "").slice(0, 18) });
  }

  // Velosia's free-text condition -> the new KA option labels (no "Defekt" any more
  // -> left manual). "Neu" tries the plain option before "Neu mit Etikett".
  function kaConditionCandidates(condition) {
    var target = KA_CONDITION_MAP[norm(condition || "")];
    if (!target || target === "Defekt") return [];
    if (target === "Neu") return ["Neu", "Neu mit Etikett"];
    return [target];
  }

  // Men's jeans waist -> KA's letter sizing. KA jeans offer ONLY XS…8XL (no waist
  // field), so "W36" must become "XL" to match. Approximate but the user reviews.
  function kaWaistToLetter(w) {
    w = parseInt(w, 10);
    if (!w) return null;
    if (w <= 28) return "XS";
    if (w <= 30) return "S";
    if (w <= 32) return "M";
    if (w <= 34) return "L";
    if (w <= 36) return "XL";
    if (w <= 38) return "XXL";
    if (w <= 40) return "XXXL";
    if (w <= 44) return "4XL";
    return "5XL";
  }

  // Expand a free-text size into candidates the matcher can hit against options like
  // "M (38)" / "XS (34)" / "M" / "Einheitsgröße". Order matters — letter/waist-letter
  // before the bare number so a waist size resolves to its alpha, not a DE number.
  function kaSizeCandidates(size) {
    var s = String(size || "").trim();
    if (!s) return [];
    var out = [s];
    var letter = (s.match(/\b(XXXS|XXS|XS|S|M|L|XL|XXL|XXXL|\dXL)\b/i) || [])[0];
    if (letter) out.push(letter.toUpperCase());
    // Waist/length like "W36 H34" / "W36/L34" / "36/34" -> letter equivalent.
    var waist = (s.match(/\bW\s*(\d{2})\b/i) || s.match(/^(\d{2})\s*[\/x]\s*\d{2}/i) || [])[1];
    if (waist) { var wl = kaWaistToLetter(waist); if (wl) out.push(wl); }
    var num = (s.match(/\d{2,3}/) || [])[0];
    if (num) out.push(num);
    return out.filter(function (v, i, a) { return v && a.indexOf(v) === i; });
  }

  // ----------------------------------------------------------------------------
  // Vinted category picker (in-DOM dropdown, drilled level by level)
  // ----------------------------------------------------------------------------
  //
  // Vinted's picker is an always-in-DOM dropdown:
  //   [data-testid="catalog-select-dropdown-input"]    -> opens it
  //   [data-testid="catalog-select-dropdown-content"]  -> the option list
  // The top 1-2 levels render each option with [data-testid="catalog-icon-<ID>"];
  // deeper levels render plain web_ui__Cell rows carrying only the category NAME.
  // So we drill by catalog ID where available and fall back to the level's name
  // (taken from the breadcrumb). The draft provides:
  //   vinted_path      -> "1904/4/183/1839" (chain of catalog IDs to the leaf)
  //   vinted_category  -> "Damen > Kleidung > Jeans > Boyfriend Jeans" (names)

  // The picker exists in two layouts: the DESKTOP dropdown
  // ([data-testid='catalog-select-dropdown-content']) and the MOBILE full-screen
  // modal (a dialog with a "Finde eine Kategorie" search box and plain rows). In
  // the WebView shell Vinted serves the mobile modal, so we detect both.
  // The OPEN picker modal's search box ("Finde eine Kategorie"). Must be strict: a
  // looser "contains kategorie" matched the page's top-nav/catalog search too, which
  // made the engine think the picker was already open and SKIP opening the real modal.
  function vintedCategorySearchInput() {
    var inputs = document.querySelectorAll("input[type='text'], input[type='search'], input:not([type])");
    for (var i = 0; i < inputs.length; i++) {
      var inp = inputs[i];
      if (!isInteractable(inp)) continue;
      var txt = norm(inp.placeholder || "") + " " + norm(inp.getAttribute("aria-label") || "");
      var aboutCategory = txt.indexOf("kategorie") !== -1 || txt.indexOf("category") !== -1;
      if (!aboutCategory) continue;
      if (txt.indexOf("finde") !== -1 || txt.indexOf("find") !== -1 ||
          inp.closest("[role='dialog'], [aria-modal='true']")) return inp;
    }
    return null;
  }

  // The collapsed category FIELD on the form that opens the modal when clicked.
  // Excludes the top-nav category tabs / browse links / headings.
  function vintedCategoryOpener() {
    var o = firstBySelectors([
      "[data-testid='catalog-select-dropdown-input']",
      "[data-testid='catalog-select-dropdown-chevron']",
      "[data-testid='catalog-select-dropdown']"
    ]);
    if (o) return o;
    var cands = document.querySelectorAll("[role='button'], button, [tabindex], input[readonly], li, div");
    var best = null;
    for (var i = 0; i < cands.length; i++) {
      var el = cands[i];
      if (!isInteractable(el)) continue;
      if (el.closest("a[href], header, nav, [role='navigation'], [role='tablist'], [role='tab'], #velosia-backdrop, #velosia-overlay")) continue;
      if (el.querySelector("input, textarea")) continue;
      var t = norm(el.textContent || el.getAttribute("placeholder") || el.value || "");
      if (t === "kategorie" || (t.indexOf("kategorie") !== -1 && t.length <= 24)) {
        if (!best || el.getElementsByTagName("*").length < best.getElementsByTagName("*").length) best = el;
      }
    }
    return best;
  }

  // The picker modal scoped as tightly as possible. We must NOT fall back to
  // document.body: the page BEHIND the open modal still holds catalog browse links
  // (<a href="/catalog/4833-…">) with the exact same category text, and clicking one
  // navigates away from items/new (observed live). So we scope to the dialog/sheet
  // ancestor of the search box, or the highest non-body ancestor of it.
  function vintedPickerContainer() {
    var d = document.querySelector("[data-testid='catalog-select-dropdown-content']");
    if (d) return d;
    var search = vintedCategorySearchInput();
    if (!search) return null;
    var explicit = search.closest("[role='dialog'], [aria-modal='true'], [class*='odal'], [class*='ialog'], [class*='heet'], [class*='rawer']");
    if (explicit) return explicit;
    // Walk up to the highest ancestor that is still below <body> (the modal root).
    var el = search, best = search.parentElement || search;
    while (el && el.parentElement && el.parentElement !== document.body) {
      best = el.parentElement;
      el = el.parentElement;
    }
    return best;
  }

  // Resolve the actual clickable element — but NEVER an <a href> (navigation). Beyond
  // buttons/roles we also accept a <label> or a web_ui Cell wrapper, because some Vinted
  // pickers (e.g. the size BottomSheet) render option rows as plain Cells / labels with
  // a hidden radio rather than role=button elements.
  function vintedClickable(el) {
    return (el.closest && el.closest(
      "button, li, [role='button'], [role='option'], [role='menuitem'], [role='radio'], [role='checkbox'], label, div[tabindex], [class*='Cell__cell'], [class*='Cell__default']"
    )) || el;
  }

  // Robust click for picker option rows whose React handler may sit on a label-wrapped
  // hidden radio/checkbox rather than the visible row: prefer clicking the input itself
  // (toggles the radio), else fire a full mousedown→mouseup→click sequence on the
  // resolved clickable cell (some Vinted sheets ignore a bare .click() on the text div).
  // A full pointer sequence like a real mouse click. Vinted's pickers react to
  // pointerdown since 2026-10 — a bare click() no longer opens them (live 2026-11).
  function vintedPress(el) {
    if (!el) return;
    var r = el.getBoundingClientRect ? el.getBoundingClientRect() : { left: 0, top: 0, width: 0, height: 0 };
    var o = { bubbles: true, cancelable: true, view: window, button: 0,
              clientX: r.left + Math.min(20, r.width / 2), clientY: r.top + r.height / 2 };
    var po = Object.assign({ pointerType: "mouse", isPrimary: true, pointerId: 1 }, o);
    try { el.dispatchEvent(new PointerEvent("pointerdown", po)); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent("mousedown", o)); } catch (e) {}
    try { el.dispatchEvent(new PointerEvent("pointerup", po)); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent("mouseup", o)); } catch (e) {}
    try { el.click(); } catch (e) { try { el.dispatchEvent(new MouseEvent("click", o)); } catch (e2) {} }
  }

  function vintedRobustClick(el) {
    var target = vintedClickable(el);
    if (target === el) {
      // No clickable ancestor — look for a clickable DESCENDANT (Vinted's size rows wrap
      // the option in an inner button/[role]/cell inside the <li>, where the handler is).
      var child = el.querySelector && el.querySelector(
        "[role='checkbox'], [role='radio'], [role='button'], [role='option'], button, div[tabindex], [class*='filter-grid__option'], [class*='Cell__cell'], label"
      );
      if (child) target = child;
    }
    var input = (target.querySelector && target.querySelector("input[type='radio'], input[type='checkbox']")) ||
                (el.querySelector && el.querySelector("input[type='radio'], input[type='checkbox']")) || null;
    if (input) { try { input.click(); return; } catch (e) {} }
    vintedPress(target);
  }

  // Robust, layout-agnostic match for a category row by its visible label. Works for
  // the desktop web_ui rows AND the mobile React rows (often a plain <div> with an
  // onClick and NO role/tabindex). Returns the DEEPEST element whose normalized own
  // text equals the name. CRITICAL: it never returns a navigating link or anything in
  // the page nav/header — only true in-picker option rows — so we never leave the form.
  function vintedRowMatch(root, name, exactOnly) {
    var target = norm(name);
    if (!target) return null;
    var nodes = root.querySelectorAll("button, li, div, span, p, [role='button'], [role='option'], [role='menuitem']");
    var exact = [], partial = null;
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (!isInteractable(el)) continue;
      if (el.closest("#velosia-backdrop, #velosia-overlay, #velosia-arrow")) continue;
      if (el.closest("a[href]")) continue; // never a catalog browse link
      if (el.closest("header, nav, footer, [role='navigation'], [role='tablist'], [role='tab'], [data-testid^='catalog-navigation']")) continue;
      if (el.querySelector("input, textarea, a[href]")) continue; // skip wrappers holding the search box / links
      var t = norm(el.textContent || "");
      if (!t) continue;
      if (t === target) exact.push(el);
      else if (!partial && t.indexOf(target) !== -1 && t.length <= target.length + 16) partial = el;
    }
    if (exact.length) {
      exact.sort(function (a, b) { return a.getElementsByTagName("*").length - b.getElementsByTagName("*").length; });
      return exact[0];
    }
    return exactOnly ? null : partial;
  }

  async function vintedClickLevel(id, name) {
    for (var t = 0; t < 16; t++) {
      var c = vintedPickerContainer();
      if (c && id) {
        var icon = c.querySelector("[data-testid='catalog-icon-" + id + "']");
        if (icon && isInteractable(icon)) { vintedPress(vintedClickable(icon)); return true; }
      }
      // Match option rows. The picker container often holds only the search box (the
      // option list lives in a sibling subtree), so we also search the whole document
      // — safe because vintedRowMatch excludes navigating links, so a document-wide
      // search can never drift onto a catalog browse link.
      var row = (c && vintedRowMatch(c, name)) || vintedRowMatch(document.body, name);
      if (row) { vintedPress(vintedClickable(row)); return true; }
      await sleep(350);
    }
    return false;
  }

  function vintedSetSearch(search, value) {
    try {
      setNativeValue(search, value);
      search.dispatchEvent(new Event("input", { bubbles: true }));
      search.dispatchEvent(new Event("keyup", { bubbles: true }));
    } catch (e) {}
  }

  // Diagnostic: log every element whose visible text equals the level name, with the
  // attributes that decide whether vintedRowMatch picks/excludes it. Reveals what the
  // real mobile picker rows look like (anchor? href? role?) so we can target them.
  function vintedDiag(name) {
    try {
      var target = norm(name);
      var nodes = document.querySelectorAll("a, button, li, div, span, p, [role]");
      var hits = [];
      for (var i = 0; i < nodes.length && hits.length < 8; i++) {
        var el = nodes[i];
        if (norm(el.textContent || "") !== target) continue;
        var a = el.closest("a[href]");
        var inNav = el.closest("header, nav, footer, [role='navigation'], [role='tablist'], [role='tab'], [data-testid^='catalog-navigation']");
        hits.push(el.tagName +
          (el.getAttribute && el.getAttribute("role") ? "[role=" + el.getAttribute("role") + "]" : "") +
          " href=" + (a ? a.getAttribute("href") : "-") +
          " interact=" + isInteractable(el) +
          " inNav=" + !!inNav +
          " kids=" + el.getElementsByTagName("*").length +
          " cls=" + ((el.className || "").toString().slice(0, 50)));
      }
      console.log("Velosia Vinted DIAG '" + name + "' [" + hits.length + "]: " + (hits.length ? hits.join("  ||  ") : "keine exakten Text-Treffer"));
    } catch (e) {}
  }

  // Diagnostic: log small elements whose text CONTAINS the substring (e.g. to find
  // the collapsed category field that opens the modal).
  function vintedDiagText(sub) {
    try {
      var needle = norm(sub);
      var nodes = document.querySelectorAll("[role='button'], button, [tabindex], input, li, div, span");
      var hits = [];
      for (var i = 0; i < nodes.length && hits.length < 8; i++) {
        var el = nodes[i];
        var t = norm(el.textContent || el.getAttribute("placeholder") || el.value || "");
        if (!t || t.indexOf(needle) === -1 || t.length > 28) continue;
        var inNav = el.closest("header, nav, [role='navigation'], [role='tablist'], [role='tab']");
        hits.push(el.tagName +
          (el.getAttribute && el.getAttribute("role") ? "[role=" + el.getAttribute("role") + "]" : "") +
          " '" + t.slice(0, 24) + "' inNav=" + !!inNav + " kids=" + el.getElementsByTagName("*").length +
          " cls=" + ((el.className || "").toString().slice(0, 40)));
      }
      console.log("Velosia Vinted DIAGTEXT '" + sub + "' [" + hits.length + "]: " + (hits.length ? hits.join("  ||  ") : "nichts"));
    } catch (e) {}
  }

  // Diagnostic: while the picker modal is OPEN, log its buttons / close controls
  // (incl. icon buttons via aria-label) so we can find a SAFE way to close it while
  // keeping the selection (X / Zurück / Fertig — but never Abbrechen/Cancel).
  function vintedDiagModal() {
    try {
      var nodes = document.querySelectorAll("button, [role='button'], [aria-label]");
      var out = [];
      for (var i = 0; i < nodes.length && out.length < 16; i++) {
        var el = nodes[i];
        if (!isInteractable(el)) continue;
        if (el.closest("a[href], header, nav, [role='navigation'], [role='tablist'], #velosia-overlay, #velosia-backdrop")) continue;
        var text = norm(el.textContent || "");
        var label = norm(el.getAttribute("aria-label") || "");
        var t = text || label;
        if (!t || t.length > 30) continue;
        out.push(el.tagName + " '" + t.slice(0, 22) + "'" + (label && label !== text ? " aria='" + label.slice(0, 16) + "'" : ""));
      }
      console.log("Velosia Vinted DIAGMODAL [" + out.length + "]: " + out.join("  ||  "));
    } catch (e) {}
  }

  // Diagnostic: the modal's navigation/header bar (back arrow / title / X / "Fertig")
  // — the controls deliberately excluded elsewhere, which is where the close/confirm
  // most likely lives.
  function vintedDiagNav() {
    try {
      var heads = document.querySelectorAll("[data-testid^='catalog-navigation'], [class*='Navigation'], [class*='__modal'], [class*='Modal'], [class*='__header'], [role='dialog']");
      var out = [];
      for (var h = 0; h < heads.length && out.length < 14; h++) {
        var els = heads[h].querySelectorAll("button, [role='button'], a, [aria-label], [data-testid]");
        for (var i = 0; i < els.length && out.length < 14; i++) {
          var el = els[i];
          if (!isInteractable(el)) continue;
          var text = norm(el.textContent || "");
          var label = norm(el.getAttribute("aria-label") || "");
          var tid = el.getAttribute("data-testid") || "";
          var t = text || label || tid;
          if (!t || t.length > 30) continue;
          out.push(el.tagName + " '" + t.slice(0, 18) + "'" + (tid ? " tid=" + tid.slice(0, 22) : ""));
        }
      }
      console.log("Velosia Vinted DIAGNAV [" + out.length + "]: " + (out.length ? out.join("  ||  ") : "nichts"));
    } catch (e) {}
  }

  // Diagnostic: the currently visible option-row titles (which level are we on?).
  function vintedDiagOptions() {
    try {
      var titles = document.querySelectorAll(".web_ui__Cell__title, [class*='Cell__title']");
      var out = [];
      for (var i = 0; i < titles.length && out.length < 12; i++) {
        if (!isInteractable(titles[i])) continue;
        if (titles[i].closest("[role='tab'], [role='tablist'], header, nav")) continue;
        var t = norm(titles[i].textContent || "");
        if (t) out.push("'" + t.slice(0, 22) + "'");
      }
      console.log("Velosia Vinted DIAGOPTIONS [" + out.length + "]: " + out.join(" "));
    } catch (e) {}
  }

  // The picker modal's own "Fertig" save button that commits the selected leaf and
  // closes the modal (data-testid input-dropdown-save-button). This is the modal's
  // save — NOT a form button like "Entwurf speichern"/"Hochladen".
  function vintedSaveButton() {
    var b = firstBySelectors([
      "[data-testid='input-dropdown-save-button']",
      "button[data-testid*='dropdown-save']",
      "button[data-testid*='save-button']"
    ]);
    if (b && isInteractable(b)) return b;
    var btns = document.querySelectorAll("button, [role='button']");
    for (var i = 0; i < btns.length; i++) {
      var el = btns[i];
      if (!isInteractable(el)) continue;
      if (el.closest("a[href], header, nav, [role='navigation']")) continue;
      var t = norm(el.textContent || "");
      if (t === "fertig" || t === "done") return el;
    }
    return null;
  }

  // Whether the picker modal is actually VISIBLE on screen. The "Finde eine
  // Kategorie" input lingers hidden in the DOM after the modal closes, so a plain
  // "does the input exist" check wrongly reports the picker still open — we must
  // check real visibility (size + offsetParent).
  function vintedModalVisible() {
    var s = vintedCategorySearchInput();
    if (!s) return false;
    if (s.offsetParent === null) return false;
    var r = s.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  async function selectVintedCategory(draft) {
    var ids = String(draft.vinted_path || draft.vintedPath || "").split("/").filter(Boolean);
    var names = String(draft.vinted_category || draft.vintedCategory || "")
      .split(">").map(function (s) { return s.trim(); }).filter(Boolean);
    if (names.length === 0 && ids.length === 0) return false;
    console.log("Velosia Vinted: Kategorie '" + names.join(" > ") + "' (ids " + ids.join("/") + ")");

    // Open the picker modal if it is not already open. Clicking the collapsed
    // "Kategorie" field on the form opens it (mobile) / focuses the dropdown (desktop).
    if (!vintedPickerContainer()) {
      var opener = vintedCategoryOpener();
      if (!opener) vintedDiagText("kategorie");
      console.log("Velosia Vinted: Opener=" + (opener ? (opener.tagName + " '" + norm(opener.textContent || "").slice(0, 24) + "'") : "KEINER"));
      if (opener) {
        for (var o = 0; o < 16 && !vintedPickerContainer(); o++) {
          try {
            vintedPress(opener);
            if (opener.focus) opener.focus();
          } catch (e) {}
          await sleep(300);
        }
      }
    }
    var hasSearch = !!vintedCategorySearchInput();
    console.log("Velosia Vinted: Picker offen=" + !!vintedPickerContainer() + ", Suchfeld=" + hasSearch);
    if (!vintedPickerContainer()) vintedDiagText("kategorie");
    vintedDiag(names[0] || "");

    // Strategy A — drill level by level (catalog-id icon first, then robust name
    // match). This is the most deterministic: each level only shows its own children.
    var onForm = function () { return location.pathname.indexOf("/items/new") !== -1; };
    var levels = Math.max(names.length, ids.length);
    var drilled = true;
    for (var i = 0; i < levels; i++) {
      // Safety: if a click ever navigated us off the form (e.g. a stray browse link),
      // stop immediately instead of drilling on the wrong page.
      if (!onForm()) { console.warn("Velosia Vinted: Formular verlassen (" + location.pathname + ") — Abbruch"); return false; }
      setBackdrop("Kategorie: " + (i + 1) + "/" + levels + " — " + (names[i] || "") + " …");
      var ok = await vintedClickLevel(ids[i] || null, names[i] || "");
      console.log("Velosia Vinted: Ebene " + i + " '" + (names[i] || "") + "' (id " + (ids[i] || "-") + ") -> " + (ok ? "geklickt" : "NICHT gefunden"));
      if (!ok) { vintedDiag(names[i] || ""); drilled = false; break; }
      await sleep(450);
    }
    if (drilled) {
      // Every level incl. the leaf was clicked, which SELECTS the leaf. The mobile
      // picker then needs an explicit "Fertig" tap (its own save button, testid
      // input-dropdown-save-button) to commit the selection and close the modal.
      // Success is honest: only true once the modal is actually gone (the "Finde eine
      // Kategorie" input lingers hidden in the DOM, so we check real visibility).
      await sleep(300);
      var save = vintedSaveButton();
      console.log("Velosia Vinted: Fertig-Button=" + (save ? "gefunden" : "KEINER"));
      if (save) { try { vintedPress(vintedClickable(save)); } catch (e) {} }
      for (var v = 0; v < 16 && vintedModalVisible(); v++) await sleep(300);
      var stillOpen = vintedModalVisible();
      if (stillOpen) { vintedDiagNav(); vintedDiagOptions(); }
      console.log("Velosia Vinted: nach Fertig Modal sichtbar=" + stillOpen);
      return !stillOpen;
    }

    // Strategy B (rescue) — only when drilling FAILED at some level: mobile search
    // box, type the leaf, click the matching result.
    var leaf = names.length ? names[names.length - 1] : "";
    var search = vintedCategorySearchInput();
    if (search && leaf) {
      vintedSetSearch(search, leaf);
      var clicked = false;
      for (var s = 0; s < 12; s++) {
        await sleep(300);
        var res = vintedRowMatch(vintedPickerContainer() || document.body, leaf);
        if (res) { try { vintedPress(vintedClickable(res)); clicked = true; } catch (e) {} break; }
      }
      console.log("Velosia Vinted: Suche nach '" + leaf + "' -> " + (clicked ? "Treffer geklickt" : "kein Treffer"));
      if (clicked) {
        await sleep(300);
        var save2 = vintedSaveButton();
        if (save2) { try { vintedPress(vintedClickable(save2)); } catch (e) {} }
        for (var c2 = 0; c2 < 14 && vintedModalVisible(); c2++) await sleep(300);
        var open2 = vintedModalVisible();
        console.log("Velosia Vinted: per Suche gewählt + Fertig, Modal sichtbar=" + open2);
        return !open2;
      }
    }

    console.warn("Velosia Vinted: Picker blieb offen — Kategorie nicht gesetzt");
    return false;
  }

  // ----------------------------------------------------------------------------
  // Vinted condition ("Zustand") picker — Velosia already captures the condition,
  // so we map it to Vinted's own options and select it via the same dropdown/modal
  // machinery as the category. Brand & size stay manual (no reliable source data).
  // ----------------------------------------------------------------------------
  //
  // Velosia stores a free-text German condition (Neu / Sehr Gut / Gut / …). Vinted's
  // labels differ slightly and have changed wording over time ("Etikett" vs
  // "Preisschild"), so each Velosia value maps to a PRIORITISED list of candidate
  // Vinted labels — the picker tries them in order and clicks the first present row.
  var VINTED_CONDITION_MAP = {
    "neu":               ["Neu ohne Preisschild", "Neu ohne Etikett", "Neu mit Preisschild", "Neu mit Etikett", "Neu"],
    "neuwertig":         ["Sehr gut", "Neu ohne Preisschild"],
    "sehr gut":          ["Sehr gut"],
    "gut":               ["Gut"],
    "zufriedenstellend": ["Zufriedenstellend", "Befriedigend"],
    "in ordnung":        ["Zufriedenstellend", "Befriedigend"],
    "befriedigend":      ["Zufriedenstellend", "Befriedigend"]
  };

  // The collapsed FORM field that opens a Vinted dropdown/modal, identified by its
  // visible label text (e.g. "Zustand"). Mirrors vintedCategoryOpener but generic.
  // avoidWords: when several fields share the label (e.g. "Größe" exists BOTH as the
  // clothing size AND as Vinted's shipping PACKAGE size "Klein/Mittel/Groß"), a field
  // whose surrounding section mentions one of these words is de-prioritised, so we open
  // the right one. Among equal-penalty matches the shallowest (fewest descendants) wins.
  function vintedDropdownOpener(labelNeedle, testidHints, avoidWords) {
    var o = testidHints && testidHints.length ? firstBySelectors(testidHints) : null;
    if (o) return o;
    var cands = document.querySelectorAll("[role='button'], button, [tabindex], input[readonly], li, div");
    var best = null, bestPenalty = 9, bestKids = 1e9;
    for (var i = 0; i < cands.length; i++) {
      var el = cands[i];
      if (!isInteractable(el)) continue;
      if (el.closest("a[href], header, nav, [role='navigation'], [role='tablist'], [role='tab'], #velosia-backdrop, #velosia-overlay")) continue;
      // The form field never lives inside an option sheet. Vinted keeps closed sheets
      // mounted, and their title ("Arbeitsspeicher (RAM)") would otherwise win as the
      // smallest match — clicking it opens nothing.
      if (el.closest("[role='dialog'], [aria-modal='true'], [class*='BottomSheet'], [class*='odal']")) continue;
      if (el.querySelector("input, textarea")) continue;
      var t = norm(el.textContent || el.getAttribute("placeholder") || el.value || "");
      if (t === labelNeedle || (t.indexOf(labelNeedle) !== -1 && t.length <= labelNeedle.length + 14)) {
        var penalty = 0;
        if (avoidWords && avoidWords.length) {
          var ctx = norm((el.closest("fieldset, section, [class*='Cell'], [class*='ield'], [class*='ow']") || el.parentElement || el).textContent || "");
          for (var a = 0; a < avoidWords.length; a++) { if (ctx.indexOf(avoidWords[a]) !== -1) { penalty = 1; break; } }
        }
        var box = el.getBoundingClientRect();
        if (box.width === 0 || box.height === 0) continue;
        var kids = el.getElementsByTagName("*").length;
        if (penalty < bestPenalty || (penalty === bestPenalty && kids < bestKids)) {
          best = el; bestPenalty = penalty; bestKids = kids;
        }
      }
    }
    // If avoidWords were given and the ONLY matches are penalised (e.g. only the
    // shipping package-size field matched "Größe"), open nothing — better to leave the
    // field manual than to wrongly change the package size.
    if (avoidWords && avoidWords.length && bestPenalty > 0) return null;
    return best;
  }

  // Vinted lists clothing sizes in varied notations. From the AI value (e.g. "W36 L34"
  // or "M" or "40") build a prioritised list of spellings to try against the options.
  function vintedSizeCandidates(value) {
    var out = [], seen = {};
    function add(v) { v = String(v || "").trim(); var k = norm(v); if (v && !seen[k]) { seen[k] = 1; out.push(v); } }
    add(value);
    var w = /w\s*(\d{2,3})/i.exec(value), l = /l\s*(\d{2,3})/i.exec(value);
    if (w && l) {
      // Vinted's jeans size list is keyed on the WAIST only (e.g. "W36"), with no
      // separate length option — so the waist spellings come FIRST, the combined and
      // the bare number only as fallbacks.
      add("W" + w[1]); add("W" + w[1] + " L" + l[1]); add("W" + w[1] + "/L" + l[1]);
      add(w[1] + "/" + l[1]); add(w[1]);
    } else if (w) {
      add("W" + w[1]); add(w[1]);
    } else {
      var nums = String(value).match(/\d{2,3}/g);
      if (nums && nums.length) add(nums[0]);
    }
    return out;
  }

  // Generic Vinted form dropdown: open the field (by label/testid), then click the
  // first CANDIDATE value whose option row is present, committing via the modal's
  // "Fertig" save if the picker uses one. Used for Zustand / Größe / Farbe / Material.
  // Best-effort and side-effect-safe: if the field or option is absent it just leaves
  // the value blank (returns false) — we NEVER pick a wrong option.
  // Dump the short, leaf-ish option labels currently visible in the open picker so we
  // can see EXACTLY which values Vinted offers (e.g. the real jeans size list).
  function vintedDiagPicker(tag) {
    try {
      var root = vintedPickerContainer() || document.body;
      var nodes = root.querySelectorAll("button, li, [role='option'], [role='button'], [class*='Cell'], div, span");
      var out = [], seen = {};
      for (var i = 0; i < nodes.length && out.length < 18; i++) {
        var el = nodes[i];
        if (!isInteractable(el)) continue;
        if (el.closest("a[href], header, nav, [role='tablist'], [role='tab'], #velosia-backdrop, #velosia-overlay")) continue;
        if (el.querySelector("input, textarea")) continue;
        if (el.getElementsByTagName("*").length > 3) continue;
        var t = norm(el.textContent || "");
        if (!t || t.length > 20 || seen[t]) continue;
        seen[t] = 1; out.push("'" + t + "'");
      }
      console.log("Velosia Vinted DIAGPICKER " + tag + " [" + out.length + "]: " + out.join(" "));
    } catch (e) {}
  }

  // opts.exact: only an exact option text counts (spec values — "Apple M4" must never
  // land on "Apple M4 Pro"). opts.search: the picker is a long list with its own search
  // box (Prozessor); type the candidate there so the row actually renders.
  async function selectVintedDropdownValue(fieldLabel, testidHints, candidates, logName, avoidWords, opts) {
    opts = opts || {};
    candidates = (candidates || []).filter(Boolean);
    if (!candidates.length) return false;
    var opener = vintedDropdownOpener(fieldLabel, testidHints, avoidWords);
    if (!opener) { console.log("Velosia Vinted: " + logName + "-Feld nicht gefunden — manuell"); return false; }
    var beforeText = norm(opener.textContent || opener.value || "");

    function findOptionRow() {
      // Prefer the sheet that is open for THIS field; fall back to the old wider search
      // so pickers whose sheet we can't pin down keep working as before.
      var roots = [vintedOpenPickerFor(fieldLabel), vintedPickerContainer() || document.body];
      for (var r = 0; r < roots.length; r++) {
        if (!roots[r]) continue;
        for (var k = 0; k < candidates.length; k++) {
          var row = vintedRowMatch(roots[r], candidates[k], opts.exact);
          if (row) return { row: row, label: candidates[k] };
        }
      }
      return null;
    }

    var picked = null;
    for (var attempt = 0; attempt < 3 && !picked; attempt++) {
      try {
        vintedPress(opener);
        if (opener.focus) opener.focus();
      } catch (e) {}
      for (var s = 0; s < 8 && !picked; s++) {
        await sleep(300);
        picked = findOptionRow();
        if (!picked && opts.search && s === 1) {
          var sb = vintedPickerSearchInput();
          if (sb) {
            try { sb.focus(); } catch (e) {}
            setNativeValue(sb, candidates[0]);
            sb.dispatchEvent(new Event("input", { bubbles: true }));
          }
        }
      }
    }
    if (!picked) {
      vintedDiagPicker(logName);
      console.log("Velosia Vinted: " + logName + "-Option (" + candidates.join("/") + ") nicht gefunden");
      return false;
    }
    var rowText = norm(picked.row.textContent || "").slice(0, 24);
    vintedRobustClick(picked.row);
    // Some Vinted dropdowns commit on click; the modal variant needs the "Fertig" save.
    await sleep(300);
    var save = vintedSaveButton();
    if (save) { try { vintedPress(vintedClickable(save)); } catch (e) {} await sleep(300); }

    // Verify honestly: re-read the collapsed field; it should now show the value
    // instead of the bare label. If nothing changed, the click did NOT take — report
    // the field as still open rather than falsely claiming success.
    await sleep(150);
    var after = vintedDropdownOpener(fieldLabel, testidHints, avoidWords);
    var afterText = after ? norm(after.textContent || after.value || "") : beforeText;
    var num = (norm(picked.label).match(/\d+/) || [""])[0];
    var verified = (afterText !== beforeText) || (num && afterText.indexOf(num) !== -1) ||
                   afterText.indexOf(norm(picked.label)) !== -1;
    console.log("Velosia Vinted: " + logName + " Kandidat='" + picked.label + "' Zeile='" + rowText +
      "' -> " + (verified ? "übernommen" : "Klick OHNE Übernahme (Feld unverändert)"));
    return !!verified;
  }

  // The option sheet that is open RIGHT NOW for this field: on screen and titled with
  // the field label. Vinted keeps closed sheets mounted, so a document-wide search for
  // "16 GB" in the RAM sheet would also hit the (closed) Speicherkapazität sheet's row.
  function vintedOpenPickerFor(labelNeedle) {
    var sel = "[role='dialog'], [aria-modal='true'], [class*='odal'], [class*='heet'], [class*='ialog']";
    var nodes = document.querySelectorAll(sel), best = null, bestKids = 1e9;
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (!isInteractable(el)) continue;
      if (el.closest("#velosia-backdrop, #velosia-overlay")) continue;
      var r = el.getBoundingClientRect();
      if (r.width < 50 || r.height < 50 || r.bottom <= 0 || r.top >= window.innerHeight) continue;
      if (norm(el.textContent || "").indexOf(labelNeedle) === -1) continue;
      var kids = el.getElementsByTagName("*").length;
      // The smallest such container is the sheet itself, not the page around it.
      if (kids > 3 && kids < bestKids) { best = el; bestKids = kids; }
    }
    return best;
  }

  // The search box INSIDE an open option picker ("Suche nach einem Prozessor") —
  // never the page's own "Suche Artikel" box in the header.
  function vintedPickerSearchInput() {
    var inputs = document.querySelectorAll("input[type='text'], input[type='search'], input:not([type])");
    for (var i = 0; i < inputs.length; i++) {
      var inp = inputs[i];
      if (!isInteractable(inp)) continue;
      if (inp.closest("header, nav, [role='navigation'], #velosia-backdrop, #velosia-overlay")) continue;
      var txt = norm(inp.placeholder || "") + " " + norm(inp.getAttribute("aria-label") || "");
      if (txt.indexOf("suche nach") !== -1 || txt.indexOf("search for") !== -1 ||
          inp.closest("[role='dialog'], [aria-modal='true']")) return inp;
    }
    return null;
  }

  // Computer specs (Desktop-Computer / Laptops). Vinted spells capacities "256 GB",
  // "1 TB", "2,5 TB" and CPUs "Apple M4"; normalise the AI/user value to that.
  function vintedCapacityCandidates(v) {
    var raw = String(v || "").trim();
    if (!raw) return [];
    var m = raw.replace(",", ".").match(/(\d+(?:\.\d+)?)\s*(tb|gb)/i);
    if (!m) return [raw];
    var n = parseFloat(m[1]), unit = m[2].toUpperCase();
    if (unit === "GB" && n >= 1000 && (n % 1024 === 0 || n % 1000 === 0)) {
      n = n % 1024 === 0 ? n / 1024 : n / 1000;
      unit = "TB";
    }
    var out = [String(n).replace(".", ",") + " " + unit];
    if (out.indexOf(raw) === -1) out.push(raw);
    return out;
  }

  function vintedCpuCandidates(v) {
    var raw = String(v || "").trim().replace(/\s+/g, " ");
    if (!raw) return [];
    // "M4 Pro" / "m4" -> "Apple M4 Pro" / "Apple M4"
    if (/^m\d/i.test(raw)) return ["Apple " + raw.replace(/^m(\d)/i, "M$1"), raw];
    return [raw];
  }

  function vintedOsCandidates(v) {
    var t = norm(v);
    if (!t) return [];
    if (/mac ?os|os x|osx/.test(t)) return ["macOS"];
    if (t.indexOf("windows") !== -1) return ["Windows"];
    if (t.indexOf("chrome") !== -1) return ["Chrome OS"];
    if (/linux|ubuntu/.test(t)) return ["Linux"];
    if (/ohne|kein/.test(t)) return ["Ohne Betriebssystem"];
    return [String(v).trim()];
  }

  // Fill the optional spec pickers that only exist in computer categories. Exact
  // matches only; a field the category doesn't have is skipped silently, and nothing
  // is ever nagged about — these are "empfohlen", not required.
  async function selectVintedComputerSpecs(draft) {
    var specs = [
      { label: "speicherkapazität", name: "Speicherkapazität",
        value: attrValue(draft, "speicherkapazität") || attrValue(draft, "speicher"), cands: vintedCapacityCandidates },
      // Full label: the placeholder "Wähle einen Arbeitsspeicher (RAM)" is too long for
      // the opener's length window around a bare "arbeitsspeicher".
      { label: "arbeitsspeicher ram", name: "Arbeitsspeicher",
        value: attrValue(draft, "arbeitsspeicher") || attrValue(draft, "ram"), cands: vintedCapacityCandidates },
      { label: "prozessor", name: "Prozessor",
        value: attrValue(draft, "prozessor"), cands: vintedCpuCandidates, search: true },
      { label: "betriebssystem", name: "Betriebssystem",
        value: attrValue(draft, "betriebssystem"), cands: vintedOsCandidates }
    ];
    var done = [];
    for (var i = 0; i < specs.length; i++) {
      var sp = specs[i];
      if (!sp.value || !vintedDropdownOpener(sp.label, [])) continue;
      var ok = false;
      try {
        ok = await selectVintedDropdownValue(sp.label, [], sp.cands(sp.value), sp.name, null,
          { exact: true, search: !!sp.search });
      } catch (e) { ok = false; }
      if (ok) done.push(sp.name);
    }
    return done;
  }

  async function selectVintedCondition(draft) {
    var cond = norm(draft.condition || "");
    if (!cond) return false;
    var candidates = VINTED_CONDITION_MAP[cond];
    if (!candidates) { console.log("Velosia Vinted: Zustand '" + cond + "' ohne Vinted-Entsprechung — manuell"); return false; }
    return selectVintedDropdownValue("zustand", [
      // Renamed by Vinted (live 2026-11): category-condition-single-list-input.
      "[data-testid='category-condition-single-list-input']",
      "[data-testid='condition-select-dropdown-input']",
      "[data-testid='condition-select-dropdown-chevron']",
      "[data-testid='status-select-dropdown-input']"
    ], candidates, "Zustand");
  }

  // Read a single AI-extracted attribute value by its (normalised) field name, e.g.
  // attrValue(draft, "größe"). Returns "" when the AI did not provide it (so the field
  // is simply left blank rather than guessed).
  function attrValue(draft, normName) {
    var attrs = parseAttributes(draft);
    var keys = Object.keys(attrs);
    for (var i = 0; i < keys.length; i++) {
      if (norm(keys[i]) === normName) {
        var v = String(attrs[keys[i]] == null ? "" : attrs[keys[i]]).trim();
        if (v) return v;
      }
    }
    return "";
  }

  // ----------------------------------------------------------------------------
  // Vinted brand picker — a SEARCH/autocomplete field, not a fixed dropdown.
  // CRITICAL: we only commit a brand when an EXACT suggestion match appears. We never
  // create a "custom brand" — a missing brand is far better than a wrong/invented one.
  // ----------------------------------------------------------------------------

  // The brand modal's search input (after the field is opened).
  function vintedBrandSearchInput() {
    var inputs = document.querySelectorAll("input[type='text'], input[type='search'], input:not([type])");
    for (var i = 0; i < inputs.length; i++) {
      var inp = inputs[i];
      if (!isInteractable(inp)) continue;
      if (inp.closest("#velosia-backdrop, #velosia-overlay")) continue;
      var txt = norm(inp.placeholder || "") + " " + norm(inp.getAttribute("aria-label") || "");
      if (txt.indexOf("marke") !== -1 || txt.indexOf("brand") !== -1) return inp;
      if (inp.closest("[role='dialog'], [aria-modal='true']")) return inp;
    }
    return null;
  }

  // A suggestion row whose normalised text EXACTLY equals the brand. Equality alone
  // already excludes "X als Marke hinzufügen" rows (they carry extra words). Never a
  // link/nav element. Returns the shallowest exact match.
  function vintedBrandExactRow(target) {
    var root = vintedPickerContainer() || document.body;
    var nodes = root.querySelectorAll("button, li, div, span, p, [role='button'], [role='option'], [role='menuitem']");
    var best = null;
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (!isInteractable(el)) continue;
      if (el.closest("#velosia-backdrop, #velosia-overlay")) continue;
      if (el.closest("a[href], header, nav, [role='navigation'], [role='tablist'], [role='tab']")) continue;
      if (el.querySelector("input, textarea, a[href]")) continue;
      if (norm(el.textContent || "") !== target) continue;
      if (!best || el.getElementsByTagName("*").length < best.getElementsByTagName("*").length) best = el;
    }
    return best;
  }

  async function selectVintedBrand(draft) {
    var brand = attrValue(draft, "marke");
    if (!brand) return false;                       // AI gave no brand -> leave blank
    var target = norm(brand);

    var opener = vintedDropdownOpener("marke", [
      "[data-testid='brand-select-dropdown-input']",
      "[data-testid='brand-select-dropdown-chevron']",
      "[data-testid='brand-select-dropdown']"
    ]);
    if (!opener) { console.log("Velosia Vinted: Marke-Feld nicht gefunden — manuell"); return false; }

    var search = null;
    for (var o = 0; o < 12 && !search; o++) {
      try {
        vintedPress(opener);
        if (opener.focus) opener.focus();
      } catch (e) {}
      await sleep(300);
      search = vintedBrandSearchInput();
    }
    if (!search) { console.log("Velosia Vinted: Marken-Suchfeld nicht gefunden — manuell"); return false; }

    vintedSetSearch(search, brand);
    var clicked = false;
    for (var s = 0; s < 16 && !clicked; s++) {
      await sleep(300);
      var row = vintedBrandExactRow(target);
      if (row) { try { vintedPress(vintedClickable(row)); clicked = true; } catch (e) {} }
    }
    if (!clicked) {
      console.log("Velosia Vinted: keine EXAKTE Marke '" + brand + "' in Vinteds Vorschlägen — bleibt LEER (keine Halluzination)");
      return false;
    }
    await sleep(250);
    var save = vintedSaveButton();
    if (save) { try { vintedPress(vintedClickable(save)); } catch (e) {} await sleep(300); }
    console.log("Velosia Vinted: Marke '" + brand + "' gesetzt (exakter Treffer)");
    return true;
  }

  // ----------------------------------------------------------------------------
  // eBay (V2.8). Calibrated live on ebay.de 2026-11 (narrow + wide layouts), see
  // memory "ebay-sell-form-recon". The flow has up to three pages:
  //   /sl/prelist/suggest  — "Was möchten Sie verkaufen?": title + Weiter/Finden.
  //                          eBay derives the category from the title itself.
  //   /sl/prelist/identify — (wide layout, electronics) catalog products to pick
  //                          from + a condition step; we never take a catalog
  //                          product (it brings foreign photos/specs).
  //   /lstng               — the listing form (Marko, not React). It autosaves a
  //                          draft in the user's account as soon as it opens.
  // ----------------------------------------------------------------------------

  var EBAY_TITLE_MAX = 80;

  // Velosia condition -> eBay condition labels, best first. The offered set
  // depends on the category (fashion: "Gebraucht - Gut" …; electronics: Neu /
  // Neu: Sonstige / Gebraucht / Als Ersatzteil/defekt).
  var EBAY_CONDITION_MAP = {
    "neu":               ["Neu", "Neu ohne Etikett", "Neu: Sonstige"],
    "neuwertig":         ["Gebraucht - Hervorragend", "Gebraucht", "Neu: Sonstige"],
    "sehr gut":          ["Gebraucht - Hervorragend", "Gebraucht"],
    "gut":               ["Gebraucht - Gut", "Gebraucht"],
    "zufriedenstellend": ["Gebraucht - Akzeptabel", "Gebraucht"],
    "in ordnung":        ["Gebraucht - Akzeptabel", "Gebraucht"],
    "befriedigend":      ["Gebraucht - Akzeptabel", "Gebraucht"],
    "defekt":            ["Als Ersatzteil / defekt", "Als Ersatzteil/defekt", "Als Ersatzteil"]
  };

  function ebayConditionCandidates(condition) {
    var c = norm(condition);
    return EBAY_CONDITION_MAP[c] || [];
  }

  // First line of a control's text, whitespace collapsed, lower case.
  // Icon-only buttons (the mobile title page's search button) carry their name
  // in aria-label only.
  function ebayLabelOf(el) {
    var t = String((el && (el.innerText || el.textContent)) || "").split("\n")[0];
    t = t.replace(/\s+/g, " ").trim();
    if (!t && el && el.getAttribute) t = String(el.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
    return t.toLowerCase();
  }

  // Exact label, or the label plus eBay's bracketed hint ("Neu: Sonstige (siehe
  // Artikelbeschreibung)"). A bare prefix is not enough: "Neu" must not hit
  // "Neu mit Etikett", "Gebraucht" not "Gebraucht - Akzeptabel".
  function ebayLabelMatches(label, cand) {
    var c = String(cand || "").replace(/\s+/g, " ").trim().toLowerCase();
    return !!c && (label === c || label.indexOf(c + " (") === 0);
  }

  function ebayVisible(el) {
    return !!(el && el.offsetParent !== null && isInteractable(el));
  }

  // The first visible button whose own text (first line) matches one of the
  // needles exactly or as a prefix ("Neu: Sonstige (siehe Artikelbeschreibung)").
  // Buttons of the listing form the engine must never press: they save the
  // draft and leave the form, show a preview, or publish.
  var EBAY_FORBIDDEN = ["speichern", "vorschau", "artikel kostenlos einstellen", "artikel einstellen", "angebot einstellen"];

  function ebayForbidden(label) {
    for (var f = 0; f < EBAY_FORBIDDEN.length; f++) {
      if (label.indexOf(EBAY_FORBIDDEN[f]) !== -1) return true;   // also "Entwurf speichern"
    }
    return false;
  }

  function ebayButton(needles, root) {
    var btns = (root || document).querySelectorAll("button, [role='button'], a[role='button']");
    for (var n = 0; n < needles.length; n++) {
      for (var i = 0; i < btns.length; i++) {
        var b = btns[i];
        if (!ebayVisible(b)) continue;
        if (ebayForbidden(ebayLabelOf(b))) continue;
        if (ebayLabelMatches(ebayLabelOf(b), needles[n])) return b;
      }
    }
    return null;
  }

  // "Weiter zum Angebot" / "Weiter" — enabled, visible; the last one wins (the
  // dialog's button sits after the page's).
  function ebayContinueButton() {
    var btns = document.querySelectorAll("button");
    var found = null;
    for (var i = 0; i < btns.length; i++) {
      var t = norm(btns[i].innerText || btns[i].textContent || "");
      if ((t === "weiter zum angebot" || t === "weiter") && ebayVisible(btns[i]) && !btns[i].disabled) found = btns[i];
    }
    return found;
  }

  // Condition on the prelist pages: a dialog of radios (electronics) or a list of
  // cards (fashion), then "Weiter zum Angebot"/"Weiter".
  async function ebayPickPrelistCondition(draft) {
    var cands = ebayConditionCandidates(draft.condition);
    if (!cands.length) return false;
    for (var tries = 0; tries < 12; tries++) {
      // Radios with a label.
      var labels = document.querySelectorAll("label");
      for (var c = 0; c < cands.length; c++) {
        for (var i = 0; i < labels.length; i++) {
          if (!ebayLabelMatches(ebayLabelOf(labels[i]), cands[c])) continue;
          var radio = labels[i].control || labels[i].querySelector("input[type='radio']") ||
                      (labels[i].htmlFor ? document.getElementById(labels[i].htmlFor) : null);
          if (radio && ebayVisible(labels[i])) {
            radio.click();
            await sleep(400);
            if (radio.checked) return true;
          }
        }
      }
      // Radios whose text sits next to them instead of in a linked <label>
      // (mobile condition page with only "Neu" / "Gebraucht", live 2026-11).
      var radios = document.querySelectorAll("input[type='radio']");
      for (var c2 = 0; c2 < cands.length; c2++) {
        for (var r = 0; r < radios.length; r++) {
          var rb = radios[r];
          if (rb.labels && rb.labels.length) continue;   // handled above
          var box = rb.parentElement;
          for (var up = 0; up < 3 && box && !ebayLabelOf(box); up++) box = box.parentElement;
          if (!box || !ebayLabelMatches(ebayLabelOf(box), cands[c2])) continue;
          rb.click();
          await sleep(400);
          if (rb.checked) return true;
        }
      }
      // Cards.
      var card = ebayButton(cands);
      if (card) { card.click(); await sleep(400); return true; }
      await sleep(500);
    }
    return false;
  }

  // Phase "prelist": type the title, continue. eBay picks the category.
  async function ebayPrelist(draft) {
    // The title field in the page body — never eBay's header search (#gh-…),
    // which would start a product search instead of a new listing.
    function titleInput(anywhere) {
      var els = document.querySelectorAll(anywhere ? "input" : "main input");
      for (var k = 0; k < els.length; k++) {
        var el = els[k];
        var type = (el.getAttribute("type") || "text").toLowerCase();
        if (type !== "text" && type !== "search") continue;
        if (!isInteractable(el) || el.offsetParent === null) continue;
        if (el.closest("header, #gh, [id^='gh-'], nav")) continue;
        return el;
      }
      return null;
    }
    var input = null;
    for (var i = 0; i < 20 && !input; i++) {
      input = titleInput(false) || (i >= 10 ? titleInput(true) : null);
      if (!input) await sleep(400);
    }
    if (!input || !draft.title) return false;
    fillField(input, clampTitle(draft.title, EBAY_TITLE_MAX));
    await sleep(700);
    var btn = ebayContinueButton() || (input.form ? ebayButton(["finden", "suchen"], input.form) : null);
    if (btn && !btn.disabled) { btn.click(); return true; }
    if (input.form) {
      try { input.form.requestSubmit ? input.form.requestSubmit() : input.form.submit(); return true; } catch (e) {}
    }
    return false;
  }

  // Phase "identify": skip the catalog product, pick the condition, continue.
  async function ebayIdentify(draft) {
    for (var i = 0; i < 16; i++) {
      var skip = ebayButton(["ohne passendes produkt fortfahren", "ohne passendes produkt"]);
      if (skip) { skip.click(); await sleep(1200); break; }
      if (document.querySelector("input[type='radio']") || ebayContinueButton()) break;
      await sleep(500);
    }
    var condOk = await ebayPickPrelistCondition(draft);
    if (!condOk) return { condition: false, continued: false };
    await sleep(400);
    // On the mobile page the first click only switches the view
    // (view=sellnode-condition, live 2026-11); click again while the page stays.
    var startPath = window.location.pathname;
    for (var k = 0; k < 3; k++) {
      var go = null;
      for (var g = 0; g < 6 && !go; g++) {
        go = ebayContinueButton();
        if (!go) await sleep(400);   // may be re-rendering after a view switch
      }
      if (!go) break;
      go.click();
      for (var w = 0; w < 10; w++) {
        await sleep(500);
        if (window.location.pathname !== startPath) return { condition: true, continued: true };
      }
    }
    // Still here: drop the backdrop (caller) so the user can go on by hand.
    return { condition: true, continued: false };
  }

  // Photos already on the eBay form: its counter reads "4/25" or
  // "4 von 25 Fotos oder Videos wurden hochgeladen".
  // null when no counter is on the page (unknown — never assume 0 then).
  function ebayPhotoCount() {
    var t = document.body ? document.body.innerText : "";
    var m = /(\d+)\s*von\s*\d+\s*Fotos/.exec(t) || /(?:^|\n)[^\n]{0,12}?(\d+)\s*\/\s*(?:24|25)\s*(?:\n|$)/.exec(t);
    if (!m) return null;
    var n = parseInt(m[1], 10);
    return isNaN(n) ? null : n;
  }

  // Phase "drafts" ("Entwürfe verwalten"): nothing is done there any more. The
  // earlier redirect to it was the engine's own click on "Speichern" (fixed in
  // 2.8.11); continuing some draft by title could pick another item's draft.
  async function ebayDrafts() { return false; }

  // The prepared item specifics: {values: {name: [values]}, required: [names]}.
  function ebayPreparedAspects(draft) {
    var raw = draft && draft.ebay_aspects;
    if (!raw) return null;
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (e) { return null; }
    }
    if (!raw || typeof raw !== "object") return null;
    return {
      values: (raw.values && typeof raw.values === "object") ? raw.values : {},
      required: Array.isArray(raw.required) ? raw.required : []
    };
  }

  function ebayAspectButton(name) {
    var btns = document.querySelectorAll("button[name^='attributes.']");
    for (var i = 0; i < btns.length; i++) {
      if (btns[i].getAttribute("name") === "attributes." + name) return btns[i];
    }
    return null;
  }

  function ebayAspectRow(btn) {
    var r = btn;
    while (r && !(r.classList && r.classList.contains("summary__attributes--field"))) r = r.parentElement;
    return r || (btn && btn.parentElement);
  }

  // Visible text of an eBay list entry or field: without the screen-reader-only
  // ".clipped" spans eBay appends ("CD-Brenner" + hidden "CD bis Brenner").
  function ebayVisibleText(el) {
    if (!el) return "";
    var c = el.cloneNode(true);
    var hidden = c.querySelectorAll(".clipped, .clipped--stealth, [aria-hidden='true']");
    for (var i = 0; i < hidden.length; i++) hidden[i].remove();
    return String(c.textContent || "").replace(/\s+/g, " ").trim();
  }

  function ebayAspectValue(btn) {
    return ebayVisibleText(btn);
  }

  async function ebayToggleAspect(btn, open) {
    var isOpen = btn.getAttribute("aria-expanded") === "true";
    if (isOpen !== open) { btn.click(); await sleep(open ? 550 : 300); }
  }

  // Set one aspect. Values are eBay's own spellings (the backend took them from
  // eBay's lists); each is searched and its exact menu entry clicked — single
  // choice (menuitemradio) or multiple (menuitemcheckbox). Nothing is invented: a
  // value without an exact entry is left out.
  async function ebaySetAspect(name, values) {
    var btn = ebayAspectButton(name);
    if (!btn) return null;               // not a field of this category
    var row = ebayAspectRow(btn);
    var setAny = false;
    try {
      for (var v = 0; v < values.length; v++) {
        var want = norm(values[v]);
        if (!want) continue;
        await ebayToggleAspect(btn, true);
        var input = row && row.querySelector(
          "input:not([type='hidden']):not([type='checkbox']):not([type='radio'])");
        if (input) {
          try { input.focus(); } catch (e) {}
          setNativeValue(input, String(values[v]));
          input.dispatchEvent(new Event("input", { bubbles: true }));
          await sleep(800);
        }
        var items = row ? row.querySelectorAll("[role^='menuitem']") : [];
        var hit = null;
        for (var i = 0; i < items.length; i++) {
          if (norm(ebayVisibleText(items[i])) === want) { hit = items[i]; break; }
        }
        if (hit) {
          if (hit.getAttribute("aria-checked") !== "true") { hit.click(); await sleep(600); }
          setAny = true;
        }
        if (input && input.value) {
          setNativeValue(input, "");
          input.dispatchEvent(new Event("input", { bubbles: true }));
        }
      }
    } finally {
      try { await ebayToggleAspect(btn, false); } catch (e) {}
    }
    // Judge by the field's shown value once the list is closed (eBay re-renders
    // the menu, so the clicked entry may be stale by now).
    if (!setAny) return false;
    var shown = norm(ebayAspectValue(btn));
    for (var k = 0; k < values.length; k++) {
      if (norm(values[k]) && shown.indexOf(norm(values[k])) !== -1) return true;
    }
    return false;
  }

  // Without eBay's API (no prepared specifics) the form itself says which item
  // specifics this category has and which values each list offers: open every
  // still-empty field once, read its entries, close it. Bounded so a huge
  // category can't keep the backdrop up for long.
  async function ebayReadFormAspects(skipNames) {
    var out = [];
    var btns = document.querySelectorAll("button[name^='attributes.']");
    var deadline = Date.now() + 25000;
    var opened = 0;
    for (var i = 0; i < btns.length && out.length < 20 && opened < 30 && Date.now() < deadline; i++) {
      var btn = btns[i];
      var name = String(btn.getAttribute("name") || "").slice("attributes.".length);
      if (!name || skipNames.indexOf(name) !== -1 || ebayAspectValue(btn)) continue;
      if (!btn.getClientRects().length) continue;   // collapsed "more specifics"
      // Identifiers can't be read off photos and text — never let the AI pick one
      // from a list (it chose the brand as "Herstellernummer" in a live test).
      if (/herstellernummer|mpn|\bean\b|gtin|isbn|upc|seriennummer|modellnummer/i.test(name)) continue;
      var row = ebayAspectRow(btn);
      opened++;
      try {
        await ebayToggleAspect(btn, true);
        // The list may render a moment after the field opens (slower on phones).
        var items = [];
        for (var wait = 0; wait < 8; wait++) {
          items = row ? row.querySelectorAll("[role^='menuitem']") : [];
          if (items.length) break;
          await sleep(250);
        }
        var values = [];
        var multi = false;
        for (var k = 0; k < items.length && values.length < 400; k++) {
          var v = ebayVisibleText(items[k]);
          if (v && v.length <= 65 && values.indexOf(v) === -1) values.push(v);
          if (items[k].getAttribute("role") === "menuitemcheckbox") multi = true;
        }
        var required = !!(row && (!!row.querySelector(".required-field") || String(row.innerText || "").slice(0, 80).indexOf("*") !== -1));
        if (values.length) out.push({ name: name, values: values, multi: multi, required: required });
      } catch (e) {
      } finally {
        try { await ebayToggleAspect(btn, false); } catch (e2) {}
      }
    }
    return out;
  }

  // Ask the backend (AI) which offered values fit this draft. Android: through the
  // native bridge (the page holds no credentials); extension: fetch with its token.
  // Resolves to {name: [values]} or null.
  function ebayRequestAspects(draft, options, aspects) {
    // Stay well below the backend's request limit (bytes, umlauts count twice).
    var body = JSON.stringify({ aspects: aspects });
    while (body.length > 100000 && aspects.length) {
      aspects = aspects.map(function (a) { return Object.assign({}, a, { values: a.values.slice(0, Math.floor(a.values.length / 2)) }); });
      body = JSON.stringify({ aspects: aspects });
    }
    var nb = nativeBridge("pickEbayAspects");
    if (nb) {
      return new Promise(function (resolve) {
        var done = false;
        window.__velosiaEbayAspectsCb = function (json) {
          if (done) return;
          done = true;
          try { var data = typeof json === "string" ? JSON.parse(json) : json; resolve((data && data.values) || null); }
          catch (e) { resolve(null); }
        };
        try { nb.pickEbayAspects(body); } catch (e) { done = true; resolve(null); return; }
        setTimeout(function () { if (!done) { done = true; resolve(null); } }, 50000);
      });
    }
    if (options && options.backendUrl && options.token && draft && draft.id != null) {
      return fetch(options.backendUrl + "/api/drafts/" + draft.id + "/ebay-form-aspects", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": "Bearer " + options.token },
        body: body
      }).then(function (r) { return r.ok ? r.json() : null; })
        .then(function (d) { return (d && d.values) || null; })
        .catch(function () { return null; });
    }
    return Promise.resolve(null);
  }

  // Velosia's own attributes for the same-named eBay fields, used when no
  // prepared item specifics exist (no eBay API key, or preparing failed).
  function ebayAspectsFromAttributes(draft) {
    var out = {};
    [["Marke", "marke"], ["Farbe", "farbe"], ["Größe", "größe"], ["Material", "material"]].forEach(function (p) {
      var v = attrValue(draft, p[1]);
      if (v) out[p[0]] = [v];
    });
    return out;
  }

  // The description lives in a rich-text iframe for display; what eBay saves is
  // textarea[name=description], reachable only in the "HTML-Code anzeigen" mode
  // (writing into the iframe is cosmetic — verified live). Text -> <p> paragraphs.
  function ebayDescriptionHtml(text) {
    var esc = function (s) {
      return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    };
    return String(text || "").replace(/\r/g, "").split(/\n\s*\n/).map(function (p) {
      p = p.trim();
      return p ? "<p>" + esc(p).replace(/\n/g, "<br>") + "</p>" : "";
    }).join("");
  }

  // Mobile layout (live 2026-11): the description is only a summary with a
  // "Beschreibung bearbeiten" button that opens a full-screen panel with the editor
  // (iframe #se-rte-frame__sidepane, a contenteditable div) and "Fertig". No HTML
  // mode there. eBay only takes over what arrives as editing commands
  // (insertText/insertParagraph; insertHTML is ignored) followed by keyup + blur,
  // then "Fertig" — verified by reloading the draft.
  async function ebaySetDescriptionMobile(text) {
    var open = document.querySelector("button[aria-label='Beschreibung bearbeiten']");
    if (!open) return false;
    open.click();
    var frame = null, ed = null;
    for (var i = 0; i < 20 && !ed; i++) {
      await sleep(250);
      frame = document.getElementById("se-rte-frame__sidepane");
      try { ed = frame && frame.contentDocument && frame.contentDocument.querySelector("[contenteditable='true']"); } catch (e) { ed = null; }
    }
    if (!ed) {
      // Don't leave the full-screen panel over the form.
      var close = ebayButton(["fertig"]);
      if (close) { close.click(); await sleep(500); }
      return false;
    }
    var d = frame.contentDocument, w = frame.contentWindow;
    try { frame.focus(); w.focus(); } catch (e) {}
    ed.focus();
    var range = d.createRange();
    range.selectNodeContents(ed);
    var sel = w.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    var paras = String(text).replace(/\r/g, "").split(/\n\s*\n/);
    var ok = true;
    for (var p = 0; p < paras.length; p++) {
      var lines = paras[p].split("\n");
      if (p > 0) ok = d.execCommand("insertParagraph") && ok;
      for (var l = 0; l < lines.length; l++) {
        if (l > 0) ok = d.execCommand("insertLineBreak") && ok;
        if (lines[l]) ok = d.execCommand("insertText", false, lines[l]) && ok;
      }
    }
    await sleep(200);
    ed.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "." }));
    await sleep(200);
    ed.dispatchEvent(new Event("blur", { bubbles: true }));
    await sleep(300);
    var done = null;
    var btns = document.querySelectorAll("button");
    for (var b = 0; b < btns.length; b++) {
      if (ebayLabelOf(btns[b]) === "fertig" && ebayVisible(btns[b])) { done = btns[b]; break; }
    }
    if (done) { done.click(); await sleep(800); }
    var first = norm(paras[0]).slice(0, 30);
    return ok && !!done && norm(ed.innerText || ed.textContent || "").indexOf(first) !== -1;
  }

  async function ebaySetDescription(text) {
    if (!text) return false;
    if (!document.querySelector("input[name='descriptionEditorMode']") &&
        document.querySelector("button[aria-label='Beschreibung bearbeiten']")) {
      return ebaySetDescriptionMobile(text);
    }
    var mode = document.querySelector("input[name='descriptionEditorMode']");
    var ta = document.querySelector("textarea[name='description']");
    if (!ta) return false;
    var switched = false;
    if (mode && !mode.checked) { mode.click(); switched = true; await sleep(600); }
    var html = ebayDescriptionHtml(text);
    try { ta.focus(); } catch (e) {}
    setNativeValue(ta, html);
    ta.dispatchEvent(new Event("input", { bubbles: true }));
    ta.dispatchEvent(new Event("change", { bubbles: true }));
    try { ta.blur(); } catch (e) {}
    ta.dispatchEvent(new Event("blur", { bubbles: true }));
    await sleep(400);
    if (switched && mode && mode.checked) { mode.click(); await sleep(600); }
    ta.__velosiaKnown = true;
    return String(ta.value || "").indexOf(html.slice(0, 40)) !== -1;
  }

  // Condition inside the form (narrow layout asks for it there): a summary value
  // means it is already set; else chips, possibly behind "Weitere Artikelzustände".
  async function ebayFormCondition(draft) {
    var cands = ebayConditionCandidates(draft.condition);
    if (!cands.length) return false;
    // The condition section: from its heading "Zustand" up to the next section.
    var section = null;
    var heads = document.querySelectorAll("h2, h3");
    for (var h = 0; h < heads.length && !section; h++) {
      if (norm(heads[h].textContent) === "zustand") {
        section = heads[h].closest("section") || heads[h].parentElement;
        for (var up = 0; up < 3 && section && norm(section.innerText).length < 25; up++) section = section.parentElement;
      }
    }
    var scope = section || document;
    var summary = scope.querySelector(".smry--value");
    if (summary) {
      var cur = ebayLabelOf(summary);
      for (var c = 0; c < cands.length; c++) {
        if (ebayLabelMatches(cur, cands[c])) return true;
      }
    }
    var chip = ebayButton(cands, scope);
    if (!chip) {
      var more = ebayButton(["weitere artikelzustände ansehen"], scope);
      if (more) { more.click(); await sleep(800); }
      if (await ebayPickPrelistCondition(draft)) {
        // Confirm only inside an opened condition dialog. NEVER the form's own
        // buttons: "Speichern" saves the draft and leaves the form (to "Entwürfe
        // verwalten" / the Seller-Hub page — seen live on the phone, 2026-11).
        var dlg = null;
        var dialogs = document.querySelectorAll("[role='dialog'], dialog, .lightbox-dialog, .drawer-dialog");
        for (var dd = 0; dd < dialogs.length && !dlg; dd++) {
          if (dialogs[dd].getClientRects().length && dialogs[dd].querySelector("input[type='radio']")) dlg = dialogs[dd];
        }
        var ok = dlg ? ebayButton(["fertig", "übernehmen", "bestätigen", "weiter"], dlg) : null;
        if (ok) { ok.click(); await sleep(600); }
        return true;
      }
      return false;
    }
    chip.click();
    await sleep(700);
    return true;
  }

  // ----------------------------------------------------------------------------
  // Submit handling
  // ----------------------------------------------------------------------------

  function findButtonByText(needles) {
    var btns = document.querySelectorAll("button, input[type='submit'], a[role='button']");
    for (var i = 0; i < btns.length; i++) {
      var t = norm(btns[i].innerText || btns[i].value || "");
      for (var j = 0; j < needles.length; j++) {
        if (t.indexOf(needles[j]) !== -1) return btns[i];
      }
    }
    return null;
  }

  function findSubmitButton(platform) {
    if (platform === "ebay") {
      return findButtonByText(["artikel kostenlos einstellen", "artikel einstellen", "angebot einstellen"]) ||
             findButtonByText(["einstellen"]);
    }
    if (platform === "vinted") {
      return document.querySelector("button[data-testid*='submit']") ||
             findButtonByText(["hochladen", "einstellen", "veröffentlichen", "veroffentlichen"]) ||
             document.querySelector("button[type='submit']");
    }
    return document.querySelector("#pstad-submit") ||
           findButtonByText(["anzeige aufgeben", "veröffentlichen", "veroffentlichen", "einstellen"]) ||
           document.querySelector("button[type='submit']");
  }

  function highlightButton(btn) {
    if (!btn) return;
    try {
      btn.scrollIntoView({ behavior: "smooth", block: "center" });
      btn.style.transition = "box-shadow .4s ease";
      btn.style.boxShadow = "0 0 0 4px rgba(9,176,183,.65)";
      btn.style.borderRadius = btn.style.borderRadius || "8px";
    } catch (e) {}
  }

  async function trySubmit(platform) {
    for (var i = 0; i < 6; i++) {
      var btn = findSubmitButton(platform);
      if (btn) {
        // Auto-submit IS the publish action: arm the listing capture before clicking.
        armPublish("auto-submit");
        try { btn.click(); return true; } catch (e) {}
      }
      await sleep(1200);
    }
    return false;
  }

  // ----------------------------------------------------------------------------
  // Publish intent — a published-listing capture (the Vinted watcher below, the
  // extension's capture marker) only counts once the user, or auto-submit, has
  // actually triggered the platform's publish action. Without this gate any ad
  // opened after an autofill (e.g. someone else's) was recorded as the user's own
  // listing and then polled by the server.
  // ----------------------------------------------------------------------------

  // How long a triggered publish stays valid. Every further publish click re-arms.
  var PUBLISH_ARM_TTL_MS = 10 * 60 * 1000;

  // Labels of the publish buttons (same needles as findSubmitButton) and words that
  // mark a look-alike button that does NOT publish ("Fotos hochladen", "Als Entwurf
  // speichern", "Vorschau").
  var PUBLISH_NEEDLES = {
    vinted: ["hochladen", "einstellen", "veröffentlichen", "veroffentlichen"],
    kleinanzeigen: ["anzeige aufgeben", "veröffentlichen", "veroffentlichen", "einstellen"],
    ebay: ["einstellen"]
  };
  var NOT_PUBLISH_WORDS = ["foto", "bild", "video", "entwurf", "vorschau", "abbrechen"];

  // The autofill session of this page: {platform, draftId, options, ready, armedAt}.
  // Replaced by every autofill run. ready = filling has ended (the engine's own
  // clicks never count); armedAt stays 0 until publish was triggered.
  var publishSession = null;
  var publishListening = false;

  // Was this click on the form's publish button — the one findSubmitButton returns
  // (what the arrow points at and auto-submit clicks)? Our own UI never counts, nor
  // a link to another page (KA's header "Anzeige aufgeben" link starts a NEW ad).
  function isSubmitTarget(target, platform) {
    try {
      if (!target || target.nodeType !== 1 || !target.closest) return false;
      if (target.closest("[id^='velosia-']")) return false;
      var link = target.closest("a[href]");
      if (link && !/^\s*(#|javascript:)/i.test(link.getAttribute("href") || "")) return false;
      var btn = findSubmitButton(platform);
      var b = (btn && (btn === target || btn.contains(target))) ? btn
            : target.closest("button, input[type='submit'], [role='button']");
      if (!b) return false;
      var t = norm(b.innerText || b.value || b.textContent || "");
      for (var i = 0; i < NOT_PUBLISH_WORDS.length; i++) {
        if (t.indexOf(NOT_PUBLISH_WORDS[i]) !== -1) return false;
      }
      if (b === btn) return true;
      // Fallback for layouts where findSubmitButton picks another match first (e.g.
      // a hidden duplicate): the clicked button itself reads like "publish". Not in
      // the site's header / navigation (KA's "Anzeige aufgeben" there starts a NEW ad).
      if (b.tagName === "A" || !t || t.length > 40) return false;
      if (b.closest("header, nav, [role='navigation']")) return false;
      var needles = PUBLISH_NEEDLES[platform] || [];
      for (var j = 0; j < needles.length; j++) {
        if (t.indexOf(needles[j]) !== -1) return true;
      }
    } catch (e) {}
    return false;
  }

  // A real <form> submit of the listing form (e.g. Enter in a field or KA's form
  // post), recognised by containing the title or description field.
  function isListingForm(form, platform) {
    try {
      var map = FIELD_MAP[platform];
      if (!map || !form || form.tagName !== "FORM") return false;
      var sels = map.title.selectors.concat(map.description.selectors);
      for (var i = 0; i < sels.length; i++) {
        if (form.querySelector(sels[i])) return true;
      }
    } catch (e) {}
    return false;
  }

  function isPublishArmed(session) {
    return !!(session && session.armedAt && (Date.now() - session.armedAt) <= PUBLISH_ARM_TTL_MS);
  }

  // Record that publishing was triggered and tell the host: the extension arms its
  // capture marker (options.onPublishIntent); a native shell that implements
  // VelosiaBridge.onPublishIntent can gate its own URL capture on it.
  function armPublish(source) {
    var s = publishSession;
    if (!s || !s.ready) return;
    s.armedAt = Date.now();
    console.log("Velosia: Veröffentlichen ausgelöst (" + source + ") -> Erfassung aktiv");
    if (typeof s.options.onPublishIntent === "function") {
      try { s.options.onPublishIntent({ platform: s.platform, draftId: s.draftId, source: source }); } catch (e) {}
    }
    var nb = nativeBridge("onPublishIntent");
    if (nb) { try { nb.onPublishIntent(String(s.platform)); } catch (e) {} }
  }

  // Start this page's session (set ready once filling has ended) and listen for the
  // publish action. Capture-phase listeners on the document keep working when React
  // re-renders the button.
  function startPublishSession(platform, draft, options) {
    publishSession = {
      platform: platform, draftId: draft ? draft.id : null,
      options: options || {}, ready: false, armedAt: 0
    };
    if (!publishListening) {
      publishListening = true;
      document.addEventListener("click", function (e) {
        var s = publishSession;
        if (s && s.ready && isSubmitTarget(e.target, s.platform)) armPublish("click");
      }, true);
      document.addEventListener("submit", function (e) {
        var s = publishSession;
        if (s && s.ready && isListingForm(e.target, s.platform)) armPublish("submit");
      }, true);
    }
    return publishSession;
  }

  // ----------------------------------------------------------------------------
  // Visible feedback overlay — also serves as the "debug" view the user can read
  // to see exactly which fields were detected and which need a manual touch.
  // ----------------------------------------------------------------------------

  // One-time injection of the keyframe animations used by the backdrop spinner,
  // the bouncing "publish here" arrow and the pulsing button highlight.
  function injectStyleOnce() {
    if (document.getElementById("velosia-style")) return;
    try {
      var s = document.createElement("style");
      s.id = "velosia-style";
      s.textContent =
        "@keyframes velosia-spin{to{transform:rotate(360deg)}}" +
        "@keyframes velosia-pulse{0%,100%{box-shadow:0 0 0 4px rgba(9,176,183,.6)}50%{box-shadow:0 0 0 10px rgba(9,176,183,.12)}}" +
        "@keyframes velosia-breathe{0%,100%{transform:scale(1);opacity:.85}50%{transform:scale(1.08);opacity:1}}" +
        "@keyframes velosia-fade{from{opacity:0}to{opacity:1}}";
      (document.head || document.documentElement).appendChild(s);
    } catch (e) {}
  }

  // Vinted/Kleinanzeigen forms are partly DESKTOP layouts rendered in a mobile
  // WebView: the page is wider/taller than the screen and pinch-/pan-zoomable, so
  // position:fixed anchors to the (large) *layout* viewport, not the visible area.
  // A plain inset:0 / right:16px overlay therefore lands off-screen. visualViewport
  // gives us the visible sub-rectangle; we align every overlay to it and keep it in
  // sync while the user scrolls or zooms.
  function viewportRect() {
    var vv = window.visualViewport;
    if (vv) return { left: vv.offsetLeft, top: vv.offsetTop, width: vv.width, height: vv.height };
    return { left: 0, top: 0, width: window.innerWidth, height: window.innerHeight };
  }

  function bindViewport(fn) {
    try { fn(); } catch (e) {}
    try {
      if (window.visualViewport) {
        window.visualViewport.addEventListener("resize", fn);
        window.visualViewport.addEventListener("scroll", fn);
      }
      window.addEventListener("scroll", fn, { passive: true });
      window.addEventListener("resize", fn);
    } catch (e) {}
    return fn;
  }

  function unbindViewport(fn) {
    if (!fn) return;
    try {
      if (window.visualViewport) {
        window.visualViewport.removeEventListener("resize", fn);
        window.visualViewport.removeEventListener("scroll", fn);
      }
      window.removeEventListener("scroll", fn);
      window.removeEventListener("resize", fn);
    } catch (e) {}
  }

  // Full-screen, interaction-blocking backdrop shown WHILE the form is being
  // filled. It deliberately covers the page so the user does not tap fields the
  // engine is still populating, and it is pinned to the *visible* viewport so the
  // spinner/text never end up off-screen on a scrolled desktop-layout page.
  var _backdropSync = null;
  function ensureBackdrop() {
    injectStyleOnce();
    // The native Android shell paints an identical #velosia-backdrop at onPageStarted
    // (so the freshly-navigated form is never briefly visible un-covered). If one is
    // already present we ADOPT it instead of creating a second — but we still (re)bind
    // the viewport sync below so the spinner stays centred on scrolled/zoomed pages.
    var bd = document.getElementById("velosia-backdrop");
    if (!bd) {
      bd = document.createElement("div");
      bd.id = "velosia-backdrop";
      bd.style.cssText = [
        "position:fixed", "z-index:2147483646",
        "background:rgba(8,11,17,.80)", "-webkit-backdrop-filter:blur(2px)",
        "backdrop-filter:blur(2px)", "display:flex", "flex-direction:column",
        "align-items:center", "justify-content:center", "gap:18px",
        "pointer-events:auto", "animation:velosia-fade .2s ease",
        "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif"
      ].join(";");
      // A sleek dual-layer spinner: a gradient conic ring (masked to a thin band) over a
      // soft "breathing" glow. No progress text — the animation alone signals "working".
      var spinner =
        '<div style="position:relative;width:62px;height:62px;display:flex;align-items:center;justify-content:center;">' +
          '<div style="position:absolute;inset:8px;border-radius:50%;background:radial-gradient(circle,rgba(9,176,183,.35),transparent 70%);animation:velosia-breathe 1.8s ease-in-out infinite;"></div>' +
          '<div style="width:62px;height:62px;border-radius:50%;' +
            'background:conic-gradient(from 0deg,rgba(9,176,183,0) 0deg,#09b0b7 130deg,#ec4899 290deg,rgba(236,72,153,0) 360deg);' +
            '-webkit-mask:radial-gradient(farthest-side,transparent calc(100% - 5px),#000 calc(100% - 5px));' +
            'mask:radial-gradient(farthest-side,transparent calc(100% - 5px),#000 calc(100% - 5px));' +
            'animation:velosia-spin .9s linear infinite;"></div>' +
        '</div>';
      bd.innerHTML =
        '<div style="font-weight:700;font-size:16px;letter-spacing:.3px;background:linear-gradient(135deg,#09b0b7,#ec4899);' +
          '-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;">✨ Velosia</div>' +
        spinner +
        // Progress line — setBackdrop() writes the current step here. Without this
        // element every setBackdrop() call is a silent no-op and the field diagnostic
        // ("Kategorie 3/4 …", "Fotos werden übertragen …") is invisible.
        '<div id="velosia-backdrop-text" style="margin-top:14px;font-size:13px;font-weight:500;' +
          'color:rgba(255,255,255,.82);text-align:center;max-width:80vw;min-height:18px;letter-spacing:.2px;"></div>';
      (document.body || document.documentElement).appendChild(bd);
    }
    if (!_backdropSync) {
      _backdropSync = bindViewport(function () {
        var r = viewportRect();
        bd.style.left = r.left + "px";
        bd.style.top = r.top + "px";
        bd.style.width = r.width + "px";
        bd.style.height = r.height + "px";
      });
    }
    return bd;
  }

  function setBackdrop(text) {
    var t = document.getElementById("velosia-backdrop-text");
    if (t) t.textContent = text;
  }

  function removeBackdrop() {
    unbindViewport(_backdropSync); _backdropSync = null;
    var bd = document.getElementById("velosia-backdrop");
    if (!bd) return;
    try {
      bd.style.transition = "opacity .25s ease";
      bd.style.opacity = "0";
      setTimeout(function () { if (bd && bd.parentNode) bd.remove(); }, 280);
    } catch (e) { try { bd.remove(); } catch (e2) {} }
  }

  // Gently highlight the publish button once the form is filled (manual mode): scroll
  // it into view and overlay a pulsing ring so the user knows what to tap. The ring is
  // a standalone element animated entirely via the Web Animations API (element.animate)
  // — no CSS @keyframes, no stylesheets, nothing the platform can remove or override.
  function pointToButton(btn) {
    if (!btn) return;
    try { btn.scrollIntoView({ behavior: "smooth", block: "center" }); } catch (e) {}

    try {
      var old = document.getElementById("velosia-pulse-ring");
      if (old) old.remove();

      var ring = document.createElement("div");
      ring.id = "velosia-pulse-ring";
      ring.style.cssText = [
        "position:absolute", "z-index:2147483645", "pointer-events:none",
        "border-radius:8px", "box-sizing:border-box"
      ].join(";");

      function place() {
        var r = btn.getBoundingClientRect();
        ring.style.left = (r.left + window.scrollX) + "px";
        ring.style.top = (r.top + window.scrollY) + "px";
        ring.style.width = r.width + "px";
        ring.style.height = r.height + "px";
      }
      place();
      (document.body || document.documentElement).appendChild(ring);

      // Animate entirely via JS — immune to any CSS interference.
      if (ring.animate) {
        ring.animate([
          { boxShadow: "0 0 0 4px rgba(9,176,183,.6)" },
          { boxShadow: "0 0 0 10px rgba(9,176,183,.12)" }
        ], { duration: 1400, iterations: Infinity, direction: "alternate", easing: "ease-in-out" });
      } else {
        // Fallback: manual JS toggle for very old WebViews without WAAPI.
        ring.style.transition = "box-shadow .7s ease";
        ring.style.boxShadow = "0 0 0 4px rgba(9,176,183,.6)";
        var phase = false;
        setInterval(function () {
          phase = !phase;
          ring.style.boxShadow = phase
            ? "0 0 0 10px rgba(9,176,183,.12)"
            : "0 0 0 4px rgba(9,176,183,.6)";
        }, 700);
      }

      window.addEventListener("scroll", place, { passive: true });
      window.addEventListener("resize", place);
    } catch (e) {}
  }

  function showOverlay(result, autoSubmit) {
    try {
      var existing = document.getElementById("velosia-overlay");
      if (existing) existing.remove();

      // Only surface what STILL NEEDS a manual touch — successfully filled fields stay
      // silent (no clutter). The panel is dismissible via × or the explicit "Ok" button.
      var open = (result.manual || []).slice();
      var photosMissing = !(result.photos > 0);

      var box = document.createElement("div");
      box.id = "velosia-overlay";
      box.style.cssText = [
        "position:fixed", "z-index:2147483647", "width:300px", "max-width:86vw",
        "background:#0e121a",
        "color:#f8fafc", "border:1px solid rgba(9,176,183,.35)", "border-radius:14px",
        "box-shadow:0 12px 40px rgba(0,0,0,.55)", "padding:14px 16px",
        "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif",
        "font-size:13px", "line-height:1.45", "box-sizing:border-box"
      ].join(";");

      function row(label) {
        return '<div style="display:flex;gap:8px;align-items:flex-start;margin-top:6px;">' +
               '<span style="flex-shrink:0;color:#f59e0b;">•</span>' +
               '<span style="color:#cbd5e1;">' + label + '</span></div>';
      }

      // Name the publish button as the platform labels it ("Hochladen" on Vinted,
      // "Anzeige aufgeben" on Kleinanzeigen); the live label wins when it is short.
      var submitLabel = result.platform === "vinted" ? "Hochladen"
        : result.platform === "ebay" ? "Artikel einstellen" : "Anzeige aufgeben";
      try {
        var sb = findSubmitButton(result.platform);
        var live = sb && (sb.textContent || sb.value || "").replace(/\s+/g, " ").trim();
        if (live && live.length <= 30) submitLabel = live;
      } catch (e) {}
      submitLabel = submitLabel.replace(/[<>&]/g, "");

      var title, bodyHtml;
      if (open.length === 0 && !photosMissing) {
        // Everything the engine handles is done — short confirmation only.
        title = "✅ Alles ausgefüllt";
        bodyHtml = '<div style="margin-top:6px;color:#94a3b8;font-size:12px;">' +
          (autoSubmit ? "Wird automatisch veröffentlicht …"
                      : "Prüfe kurz und tippe unten auf <b>" + submitLabel + "</b>.") + "</div>";
      } else {
        title = "Noch offen";
        var items = open.map(function (f) { return row(f); }).join("");
        if (photosMissing) items += row("Fotos — bitte selbst hinzufügen");
        bodyHtml = items +
          '<div style="margin-top:10px;color:#94a3b8;font-size:12px;">Bitte ergänze diese Punkte' +
          (autoSubmit ? "." : ", dann tippe auf <b>" + submitLabel + "</b>.") + "</div>";
      }

      box.innerHTML =
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:2px;">' +
          '<span style="font-weight:700;background:linear-gradient(135deg,#09b0b7,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">✨ ' + title + '</span>' +
          '<span id="velosia-overlay-close" style="cursor:pointer;color:#94a3b8;font-size:18px;line-height:1;">&times;</span>' +
        '</div>' +
        bodyHtml +
        '<button id="velosia-overlay-ok" style="margin-top:12px;width:100%;border:0;cursor:pointer;' +
          'background:linear-gradient(135deg,#09b0b7,#ec4899);color:#fff;font-weight:700;font-size:13px;' +
          'padding:9px 12px;border-radius:9px;font-family:inherit;">Ok</button>';

      document.body.appendChild(box);
      // Anchor to the visible viewport's bottom-right (tracks scroll/zoom) so the
      // panel never drifts off a wide/tall desktop-layout page.
      var sync = bindViewport(function () {
        var r = viewportRect();
        box.style.left = Math.max(r.left + 8, r.left + r.width - box.offsetWidth - 16) + "px";
        box.style.top = (r.top + r.height - box.offsetHeight - 16) + "px";
      });
      function dismiss() { unbindViewport(sync); if (box && box.parentNode) box.remove(); }
      var close = document.getElementById("velosia-overlay-close");
      if (close) close.addEventListener("click", dismiss);
      var ok = document.getElementById("velosia-overlay-ok");
      if (ok) ok.addEventListener("click", dismiss);
    } catch (e) { /* overlay is best-effort, never block autofill */ }
  }

  // ----------------------------------------------------------------------------
  // Core fill (Vinted form + Kleinanzeigen step 2 form)
  // ----------------------------------------------------------------------------

  async function fillForm(draft, options, platform) {
    var map = FIELD_MAP[platform] || FIELD_MAP.vinted;
    var filled = [];
    var manual = [];
    var categoryOk = null;   // null = not applicable here, bool = picker result
    var attrCount = 0;
    // Per-attribute picker outcomes for telemetry. A key is only set when the AI
    // actually had a value for it (so a `false` means "had a value, picker failed"
    // — a likely selector break — not "no value to set").
    var fields = {};

    // Poll for the title field — both forms render asynchronously.
    setBackdrop("Formular wird gelesen …");
    var titleEl = null;
    for (var i = 0; i < 24 && !titleEl; i++) {
      titleEl = findField(map.title);
      if (!titleEl) await sleep(500);
    }

    // Photos FIRST, before any text field: on Kleinanzeigen a successful upload
    // re-initialises the form and wipes title/description/price typed before it
    // (seen live on Android, 2026-10 — PLZ filled afterwards survived). It also
    // gives the page the most time to render the previews. Prefer the DataTransfer
    // path everywhere (it uploads ALL draft photos and needs no user gesture); the
    // native chooser is only a fallback for environments without DataTransfer.
    setBackdrop("Fotos werden übertragen …");
    var photos = 0;
    // Kleinanzeigen's new react-dropzone uploader also accepts a 'drop' fallback.
    var allowDrop = platform === "kleinanzeigen";
    // eBay: a draft continued from "Entwürfe verwalten" may already hold the
    // photos of an earlier run — uploading again would double them.
    var existingPhotos = 0;
    if (platform === "ebay") {
      // The photo area of a continued draft renders late: wait for the uploader,
      // then read the counter (null = not readable -> treat as none).
      await waitForFileInput();
      for (var pc = 0; pc < 4; pc++) {
        var cnt = ebayPhotoCount();
        if (cnt !== null) { existingPhotos = cnt; break; }
        await sleep(500);
      }
    }
    if (existingPhotos > 0) {
      photos = existingPhotos;
    } else {
    // 1) Android bridge (CORS-immune: native shell supplies the photos as data URLs).
    var bridged = await uploadPhotosFromBridge(allowDrop);
    if (bridged >= 0) photos = bridged;
    }
    // 2) Browser fetch + DataTransfer (extension, or Android if the bridge is absent).
    if (photos === 0) {
      var urls = resolveImageUrls(draft, options.backendUrl);
      if (typeof DataTransfer !== "undefined" && urls.length > 0) {
        photos = await uploadPhotosDataTransfer(urls, allowDrop);
      }
    }
    // 3) Last-resort native file chooser.
    if (photos === 0 && options.imageMode === "native") photos = triggerNativeFileChooser();
    try { console.log("Velosia: Fotos übertragen -> " + photos + " (Modus " + options.imageMode + ")"); } catch (e) {}

    // Look the fields up again AFTER the photo step — the form may have re-mounted
    // its inputs, leaving references from before the upload detached.
    titleEl = findField(map.title) || titleEl;
    var descEl = findField(map.description);
    var priceEl = findField(map.price);
    var priceValue = (draft.price !== undefined && draft.price !== null) ? String(Math.round(draft.price)) : null;
    // eBay keeps cents (its field takes "9,99"); the other forms take whole euros.
    if (platform === "ebay" && priceValue !== null) {
      priceValue = (Math.round(Number(draft.price) * 100) / 100).toFixed(2).replace(".", ",").replace(/,00$/, "");
    }
    var ebayDescFound = null;

    setBackdrop("Titel, Beschreibung & Preis …");
    // A core field that HAS a value but couldn't be filled (selector didn't match)
    // must land in `manual` — otherwise the overlay stays silent and the user can
    // publish an empty listing without noticing.
    // Kleinanzeigen nimmt höchstens 65 Zeichen an (ältere Entwürfe haben bis zu 80).
    if (platform === "kleinanzeigen" && draft.title && draft.title.length > KA_TITLE_MAX) {
      draft = Object.assign({}, draft, { title: clampTitle(draft.title, KA_TITLE_MAX) });
    }
    if (platform === "ebay" && draft.title && draft.title.length > EBAY_TITLE_MAX) {
      draft = Object.assign({}, draft, { title: clampTitle(draft.title, EBAY_TITLE_MAX) });
    }
    if (fillField(titleEl, draft.title)) filled.push("Titel");
    else if (draft.title) manual.push("Titel");
    if (platform === "ebay") {
      var descOk = false;
      try { descOk = await ebaySetDescription(draft.description); } catch (e) {}
      if (descOk) filled.push("Beschreibung");
      else if (draft.description) manual.push("Beschreibung");
      // The phone layout only mounts the textarea while its editor panel is open.
      ebayDescFound = descOk || !!document.querySelector("textarea[name='description']");
      descEl = null;  // hidden textarea: skip the generic re-check below
    } else if (fillField(descEl, draft.description)) filled.push("Beschreibung");
    else if (draft.description) manual.push("Beschreibung");
    if (priceValue !== null) {
      if (fillField(priceEl, priceValue)) filled.push("Preis");
      else manual.push("Preis");
    }
    if (titleEl) titleEl.__velosiaKnown = true;
    if (descEl) descEl.__velosiaKnown = true;
    if (priceEl) priceEl.__velosiaKnown = true;

    if (platform === "kleinanzeigen") {
      selectKleinanzeigenOffer();
      var priceType = String(draft.price_type_effective || draft.price_type || "FIXED").toUpperCase();
      if (priceType !== "NEGOTIABLE") priceType = "FIXED";
      var pt = { found: false, ok: false };
      try { pt = await setKleinanzeigenPriceType(priceType); } catch (e) {}
      // VB is a deliberate choice, so it is reported either way. Festpreis was the
      // silent default before; it only counts as open when the control was there
      // and could not be set.
      if (pt.ok) filled.push(priceType === "NEGOTIABLE" ? "Preisart VB" : "Preisart Festpreis");
      else if (priceType === "NEGOTIABLE" || pt.found) {
        manual.push(priceType === "NEGOTIABLE" ? "Preisart „VB“" : "Preisart „Festpreis“");
      }
      if (options.userZip) {
        var zipEl = firstBySelectors([
          "#ad-zip-code", "input[name='zipCode']", "#postad-postcode", "input[name='postcode']", "input[placeholder*='PLZ']"
        ]);
        if (zipEl) {
          fillField(zipEl, options.userZip);
          zipEl.__velosiaKnown = true;
          zipEl.dispatchEvent(new Event("blur", { bubbles: true }));
          filled.push("PLZ");
        }
      }
      // Attributes may render slightly after the core fields. Fill once, then
      // only keep waiting/retrying while attributes are still missing — when the
      // first pass already caught everything we skip the (formerly fixed) 3.5s.
      setBackdrop("Kategorie-Details werden ausgefüllt …");
      var wantAttr = Object.keys(parseAttributes(draft)).length;
      var attrFilled = fillAttributes(draft);
      for (var pass = 0; pass < 2 && attrFilled.length < wantAttr; pass++) {
        await sleep(900);
        attrFilled = attrFilled.concat(fillAttributes(draft));
      }
      // De-dup attribute labels for the report.
      var dedupAttr = attrFilled.filter(function (v, idx, arr) { return arr.indexOf(v) === idx; });
      attrCount = dedupAttr.length;
      dedupAttr.forEach(function (lbl) { filled.push(lbl); });

      // Zustand: set it directly from draft.condition. First the old <select>/pill
      // layout, then the new 2026 React modal (radios + "Bestätigen"). Report once.
      var zustandDone = filled.some(function (l) { return norm(l).indexOf("zustand") !== -1; });
      if (!zustandDone && draft.condition) {
        if (selectKleinanzeigenCondition(draft)) { filled.push("Zustand"); zustandDone = true; }
      }
      // trySel: never let one picker's failure abort the rest of the fill.
      var trySel = async function (label, cands, exact) {
        try { return await selectKleinanzeigenAttribute(label, cands, exact); }
        catch (e) { return false; }
      };
      if (!zustandDone && draft.condition) {
        var condCands = kaConditionCandidates(draft.condition);
        if (condCands.length && await trySel("Zustand", condCands, false)) {
          filled.push("Zustand"); zustandDone = true;
        }
      }
      if (draft.condition) fields.condition = zustandDone;
      if (!zustandDone && draft.condition) manual.push("Zustand");

      // New 2026 form: Größe / Farbe / Marke are dialog/listbox/combobox pickers the
      // old fillAttributes (<select>/text only) can't drive. Values come from the AI
      // attributes; Marke is EXACT-only (never a wrong brand — leer ist besser als
      // halluziniert). A field the AI didn't provide is simply skipped.
      var alreadyFilled = function (word) {
        return filled.some(function (l) { return norm(l).indexOf(word) !== -1; });
      };
      var kaSize = attrValue(draft, "größe");
      if (kaSize && !alreadyFilled("größe") && !alreadyFilled("grosse")) {
        var kaSizeOk = await trySel("Größe", kaSizeCandidates(kaSize), false);
        fields.size = kaSizeOk;
        if (kaSizeOk) filled.push("Größe");
        else manual.push("Größe");
      }
      var kaColor = attrValue(draft, "farbe");
      if (kaColor && !alreadyFilled("farbe")) {
        var kaColorOk = await trySel("Farbe", [kaColor], false);
        fields.color = kaColorOk;
        if (kaColorOk) filled.push("Farbe");
      }
      var kaBrand = attrValue(draft, "marke");
      // Many KA categories simply have NO Marke field (e.g. "Elektronik > PCs" only
      // has Zustand + Versand). Then there is nothing to fill — don't report it as
      // open, and don't count a failure in telemetry (it would look like a broken picker).
      if (!kaHasField("Marke", /\.(brand|marke)\]?$/i)) {
        // nothing to do
      } else if (kaBrand && !alreadyFilled("marke")) {
        // selectKleinanzeigenBrand returns {ok, reason, detail}; on failure the brand
        // stays manual.
        var br = { ok: false };
        try { br = await selectKleinanzeigenBrand(kaBrand); } catch (e) { br = { ok: false }; }
        fields.brand = !!(br && br.ok);
        if (br && br.ok) filled.push("Marke");
        else manual.push("Marke");
      } else if (!kaBrand) {
        manual.push("Marke (nicht auf Fotos erkannt)");
      }
    }

    if (platform === "ebay") {
      // Price type: eBay's "Preisvorschläge zulassen" is VB; Festpreis switches it off.
      var ptE = String(draft.price_type_effective || draft.price_type || "FIXED").toUpperCase();
      var bo = document.querySelector("input[name='bestOfferEnabled']");
      if (bo) {
        var wantBo = ptE === "NEGOTIABLE";
        if (bo.checked !== wantBo) { try { bo.click(); } catch (e) {} await sleep(300); }
        if (bo.checked === wantBo) filled.push(wantBo ? "Preisvorschläge an" : "Festpreis");
      }

      setBackdrop("Zustand …");
      var eCond = false;
      if (draft.condition) {
        try { eCond = await ebayFormCondition(draft); } catch (e) { eCond = false; }
        fields.condition = eCond;
        if (eCond) filled.push("Zustand"); else manual.push("Zustand");
      }

      // Item specifics: the prepared ones (eBay's own values), else Velosia's
      // attributes for the same-named fields. What eBay pre-filled on its own and
      // we cannot back up stays, but is named for a quick check.
      setBackdrop("Artikelmerkmale …");
      var prepared = ebayPreparedAspects(draft);
      var wantAspects = prepared ? prepared.values : ebayAspectsFromAttributes(draft);
      var setNames = [];
      for (var t = 0; t < 10 && !document.querySelector("button[name^='attributes.']"); t++) await sleep(400);
      var aspectNames = Object.keys(wantAspects || {});
      for (var an = 0; an < aspectNames.length; an++) {
        var nm = aspectNames[an];
        var vals = wantAspects[nm];
        if (!Array.isArray(vals)) vals = [vals];
        var res = null;
        try { res = await ebaySetAspect(nm, vals); } catch (e) { res = false; }
        if (res === true) setNames.push(nm);
        // null = the category has no such field: no telemetry signal then.
        if (res !== null) {
          if (nm === "Marke") fields.brand = res === true;
          if (nm === "Farbe") fields.color = res === true;
          if (nm === "Größe") fields.size = res === true;
        }
      }
      // No prepared specifics (no eBay API keys): read the form's empty fields and
      // let the AI pick from exactly what they offer.
      var formRequired = [];
      if (!prepared) {
        try {
          setBackdrop("Artikelmerkmale werden gelesen …");
          var formAspects = await ebayReadFormAspects(setNames);
          formAspects.forEach(function (a) { if (a.required) formRequired.push(a.name); });
          if (formAspects.length) {
            setBackdrop("Artikelmerkmale werden gewählt …");
            var picked = await ebayRequestAspects(draft, options, formAspects);
            var pickedNames = Object.keys(picked || {});
            for (var pn = 0; pn < pickedNames.length; pn++) {
              var pv = picked[pickedNames[pn]];
              if (!Array.isArray(pv)) pv = [pv];
              var pres = null;
              try { pres = await ebaySetAspect(pickedNames[pn], pv); } catch (e) { pres = false; }
              if (pres === true && setNames.indexOf(pickedNames[pn]) === -1) setNames.push(pickedNames[pn]);
            }
          }
        } catch (e) {}
      }
      attrCount = setNames.length;
      if (setNames.length) filled.push("Merkmale (" + setNames.length + ")");

      var titleKey = norm(draft.title);
      var unchecked = [];
      var openRequired = [];
      var required = prepared ? prepared.required : formRequired;
      var allBtns = document.querySelectorAll("button[name^='attributes.']");
      for (var ab = 0; ab < allBtns.length; ab++) {
        var aName = String(allBtns[ab].getAttribute("name") || "").slice("attributes.".length);
        var aVal = ebayAspectValue(allBtns[ab]);
        var row = ebayAspectRow(allBtns[ab]);
        var starred = !!(row && (!!row.querySelector(".required-field") || String(row.innerText || "").slice(0, 80).indexOf("*") !== -1));
        if (!aVal) {
          if (required.indexOf(aName) !== -1 || starred) openRequired.push(aName);
        } else if (setNames.indexOf(aName) === -1 && titleKey.indexOf(norm(aVal)) === -1) {
          unchecked.push(aName);
        }
      }
      openRequired.forEach(function (n) { manual.push("Merkmal „" + n + "“"); });
      if (unchecked.length) {
        manual.push("Von eBay vorbelegt, bitte prüfen: " + unchecked.slice(0, 5).join(", ") +
          (unchecked.length > 5 ? " …" : ""));
      }
    }

    // Vinted: drive the category picker automatically (drilled by catalog id / name),
    // then the condition picker (Velosia captures the condition). Brand & size are
    // separate pickers with no reliable source data — still manual.
    if (platform === "vinted") {
      setBackdrop("Kategorie wird ausgewählt …");
      var vintedCatOk = false;
      if (draft.vinted_path || draft.vintedPath || draft.vinted_category || draft.vintedCategory) {
        try { vintedCatOk = await selectVintedCategory(draft); } catch (e) { vintedCatOk = false; }
        categoryOk = vintedCatOk;
      }
      if (vintedCatOk) filled.push("Kategorie");
      else manual.push("Kategorie");

      // Condition ("Zustand"): best-effort, only after the category modal has closed.
      var condOk = false;
      if (draft.condition) {
        try { condOk = await selectVintedCondition(draft); } catch (e) { condOk = false; }
      }
      if (draft.condition) fields.condition = condOk;
      if (condOk) filled.push("Zustand");
      else if (draft.condition) manual.push("Zustand");

      // Größe / Farbe / Material (fixed dropdowns) + Marke (search field). Every value
      // comes from the AI attributes; a value the AI could NOT determine is simply
      // skipped (left blank — never guessed). The brand is only set on an EXACT match.
      setBackdrop("Details werden ausgefüllt …");
      var sizeVal = attrValue(draft, "größe");
      var colorVal = attrValue(draft, "farbe");
      var materialVal = attrValue(draft, "material");
      var brandVal = attrValue(draft, "marke");

      var sizeOk = false, colorOk = false, materialOk = false, brandOk = false;
      if (sizeVal) {
        // Exclude Vinted's shipping PACKAGE size field (also labelled "Größe") via
        // avoidWords, and try several size spellings (W36 L34 / 36/34 / 36 …).
        try { sizeOk = await selectVintedDropdownValue("größe",
          ["[data-testid='category-size-single-grid-input']", "[data-testid='size-select-dropdown-input']", "[data-testid='size-select-dropdown-chevron']"],
          vintedSizeCandidates(sizeVal), "Größe",
          ["versand", "paket", "pushen", "schneller", "sichtbarkeit", "spotlight"]); } catch (e) {}
      }
      if (colorVal) {
        try { colorOk = await selectVintedDropdownValue("farbe",
          ["[data-testid='color-select-dropdown-input']", "[data-testid='color-select-dropdown-chevron']"],
          [colorVal], "Farbe"); } catch (e) {}
      }
      if (materialVal) {
        try { materialOk = await selectVintedDropdownValue("material",
          ["[data-testid='category-material-multi-list-input']", "[data-testid='material-select-dropdown-input']", "[data-testid='material-select-dropdown-chevron']"],
          [materialVal], "Material"); } catch (e) {}
      }
      if (brandVal) {
        try { brandOk = await selectVintedBrand(draft); } catch (e) {}
      }
      // Computer categories: Speicher / RAM / Prozessor / Betriebssystem.
      var specsDone = [];
      try { specsDone = await selectVintedComputerSpecs(draft); } catch (e) { specsDone = []; }
      specsDone.forEach(function (n) { filled.push(n); });

      if (sizeVal) fields.size = sizeOk;
      if (colorVal) fields.color = colorOk;
      if (materialVal) fields.material = materialOk;
      if (brandVal) fields.brand = brandOk;
      if (sizeOk) filled.push("Größe");
      if (colorOk) filled.push("Farbe");
      if (materialOk) filled.push("Material");
      if (brandOk) filled.push("Marke");

      // Only nag about the two key fashion fields, and only when they were NOT set.
      // "(nicht erkannt)" tells the user it's blank because the AI couldn't read it
      // off the photos (so they add it), vs. a picker that simply didn't match.
      // ...and only when the category HAS that field: electronics (e.g. Desktop-Computer)
      // has no Größe, so nagging about it there is a false alarm.
      var sizeAvoid = ["versand", "paket", "pushen", "schneller", "sichtbarkeit", "spotlight"];
      var hasBrandField = !!vintedDropdownOpener("marke", ["[data-testid='brand-select-dropdown-input']"]);
      var hasSizeField = !!vintedDropdownOpener("größe",
        ["[data-testid='category-size-single-grid-input']", "[data-testid='size-select-dropdown-input']"], sizeAvoid);
      if (!brandOk && hasBrandField) manual.push("Marke" + (brandVal ? "" : " (nicht auf Fotos erkannt)"));
      if (!sizeOk && hasSizeField) manual.push("Größe" + (sizeVal ? "" : " (nicht auf Fotos erkannt)"));
    } else if (!draft.category && platform !== "ebay") {
      manual.push("Kategorie");
    }

    // Final check of the core text fields: something later in the flow (late photo
    // processing, a picker re-render) may still have reset them. Re-find and refill
    // anything that lost its value; if it still won't stick, say so honestly instead
    // of "Alles ausgefüllt" over an empty title.
    await sleep(600);
    var core = [
      ["Titel", map.title, draft.title],
      ["Beschreibung", map.description, draft.description],
      ["Preis", map.price, priceValue]
    ];
    for (var ci = 0; ci < core.length; ci++) {
      var want = core[ci][2];
      if (want === undefined || want === null || want === "") continue;
      var label = core[ci][0];
      var el = findField(core[ci][1]);
      if (!el) continue;
      if (String(el.value || "").trim() === "") {
        fillField(el, want);
        el.__velosiaKnown = true;
        await sleep(150);
      }
      if (String(el.value || "").trim() === "") {
        if (manual.indexOf(label) === -1) manual.push(label);
        filled = filled.filter(function (l) { return l !== label; });
      } else if (manual.indexOf(label) !== -1) {
        // The field rendered late (Vinted's price only appears once the category is
        // set) and is filled now — withdraw the earlier "still open" report.
        manual = manual.filter(function (l) { return l !== label; });
        if (filled.indexOf(label) === -1) filled.push(label);
      }
    }

    return {
      filled: filled, manual: manual, photos: photos,
      found: { title: !!titleEl, description: ebayDescFound !== null ? ebayDescFound : !!descEl, price: !!priceEl },
      categoryOk: categoryOk, attrCount: attrCount, fields: fields
    };
  }

  // ----------------------------------------------------------------------------
  // Telemetry — anonymous structural outcome (NO listing content) so the backend
  // can automatically detect when Vinted/Kleinanzeigen change their forms.
  // ----------------------------------------------------------------------------

  // The Android shell exposes native helpers on window.VelosiaBridge. Newer app
  // builds send telemetry/capture natively with the session they hold, so the
  // engine needs no credentials in the page; the extension and older app builds
  // still pass options.token and use fetch.
  function nativeBridge(method) {
    try {
      var b = (typeof window !== "undefined") ? window.VelosiaBridge : null;
      return (b && b[method]) ? b : null;
    } catch (e) { return null; }
  }

  function sendTelemetry(payload, options) {
    try {
      payload.engine_version = VERSION;
      var nb = nativeBridge("sendTelemetry");
      if (nb) {
        try { nb.sendTelemetry(JSON.stringify(payload)); return; } catch (e) { /* fall back to fetch */ }
      }
      if (!options || !options.backendUrl) return;
      var headers = { "Content-Type": "application/json" };
      if (options.token) headers["Authorization"] = "Bearer " + options.token;
      fetch(options.backendUrl + "/api/telemetry/autofill", {
        method: "POST", headers: headers, body: JSON.stringify(payload), keepalive: true
      }).catch(function () {});
    } catch (e) { /* telemetry is best-effort, never block autofill */ }
  }

  // ----------------------------------------------------------------------------
  // Published-listing capture — read the public listing id/URL after publishing
  // (no login, no form crawl) and report it so the dashboard can track status.
  // ----------------------------------------------------------------------------

  // Map the *current* (or given) URL to {platform, listingId, listingUrl} if it
  // is a published listing page, else null. Vinted item: /items/<id>-slug;
  // Kleinanzeigen ad: /s-anzeige/<slug>/<id>-... (the "items/new" form and the KA
  // form pages return null — they are not published listings).
  function parseListingUrl(href) {
    href = href || window.location.href;
    var url;
    try { url = new URL(href); } catch (e) { return null; }
    var host = url.hostname || "";
    var path = url.pathname || "";

    if (host.indexOf("vinted") !== -1) {
      if (/\/items\/new/.test(path)) return null;
      var mv = path.match(/\/items\/(\d+)/);
      if (mv) return { platform: "vinted", listingId: mv[1], listingUrl: url.origin + path };
      return null;
    }
    if (/(^|\.)ebay\.de$/.test(host)) {
      var me = path.match(/^\/itm\/(?:[^/]+\/)?(\d{9,15})/);
      if (me) return { platform: "ebay", listingId: me[1], listingUrl: "https://www.ebay.de/itm/" + me[1] };
      return null;
    }
    if (host.indexOf("kleinanzeigen") !== -1) {
      var mk = path.match(/\/s-anzeige\/[^/]+\/(\d+)/);
      if (mk) return { platform: "kleinanzeigen", listingId: mk[1], listingUrl: url.origin + path };
      var adId = url.searchParams.get("adId") || url.searchParams.get("adID") || url.searchParams.get("adid");
      if (adId && /^\d+$/.test(adId)) return { platform: "kleinanzeigen", listingId: adId, listingUrl: null };
      return null;
    }
    return null;
  }

  // POST the captured listing to the backend. options = {backendUrl, token,
  // draftId, href?}. No-ops unless the page is a real listing and a draftId +
  // backendUrl are known. Idempotent on the server, so it is safe to fire from
  // multiple hosts (engine watcher + capture content script).
  async function captureListing(options) {
    options = options || {};
    var info = parseListingUrl(options.href || window.location.href);
    if (!info) return null;
    var draftId = (options.draftId != null) ? options.draftId : options.draft_id;
    if (draftId == null || !options.backendUrl) return null;
    try {
      var headers = { "Content-Type": "application/json" };
      if (options.token) headers["Authorization"] = "Bearer " + options.token;
      await fetch(options.backendUrl + "/api/listings/published", {
        method: "POST",
        headers: headers,
        body: JSON.stringify({
          draft_id: draftId,
          platform: info.platform,
          listing_id: info.listingId,
          listing_url: info.listingUrl
        }),
        keepalive: true
      });
      return info;
    } catch (e) { return null; }
  }

  // Vinted is a React SPA: publishing does NOT reliably navigate to /items/<id>
  // (esp. on mobile it may stay on /items/new or jump elsewhere), so URL-watching
  // alone misses the event. The robust signal is the item-creation API RESPONSE:
  // we patch fetch/XHR before publish and read the new item's id out of the JSON
  // the moment Vinted's create call returns — independent of any navigation. This
  // only works where the engine shares the page's JS world (Android WebView); the
  // extension's isolated content-script world never sees the page's requests.
  // Backstop (the only path in the extension): watch the URL — but only the FIRST
  // navigation away from the form counts, and only after the publish action.

  // The Vinted watch of this page; a new autofill run supersedes it.
  var vintedWatch = null;
  var vintedNetPatched = false;

  // Vinted's create-item call (confirmed live): POST /api/v2/item_upload/items.
  // Plain POST /api/v2/items is kept as an alternative. Exact path only: a sub-path
  // (/items/<id>/…) is an action on an existing — possibly foreign — item.
  function isVintedCreateRequest(url, method) {
    if (!/^post$/i.test(method || "")) return false;
    var u;
    try { u = new URL(url, window.location.href); } catch (e) { return false; }
    if ((u.hostname || "").indexOf("vinted") === -1) return false;
    return /^\/api\/v\d+\/(item_upload\/)?items\/?$/i.test(u.pathname || "");
  }

  // Build an absolute listing URL from whatever the API gave us (full url, a
  // relative path, or just an id) so the backend can poll it later.
  function vintedListingUrl(item) {
    var origin = "";
    try { origin = window.location.origin; } catch (e) {}
    var u = item && (item.url || item.path);
    if (u) return /^https?:/.test(u) ? u : (origin + u);
    if (item && item.id != null) return origin + "/items/" + item.id;
    return null;
  }

  // One capture per watch. Also accepted after the URL watch ended: a create
  // response can land after Vinted already routed away from the form.
  function fireVintedCapture(w, item) {
    if (!w || w.captured || w.superseded || !item || item.id == null) return;
    w.captured = true;
    w.done = true;
    var o = w.options;
    var listingUrl = vintedListingUrl(item);
    console.log("Velosia: Vinted-Item erkannt -> id=" + item.id + " url=" + listingUrl);
    // Backend capture (works on desktop too; idempotent server-side). Skipped when
    // no token was passed and the native shell captures instead (newer app builds).
    var nb = nativeBridge("onListingPublished");
    if (o.token || !nb) {
      captureListing({
        backendUrl: o.backendUrl, token: o.token,
        draftId: w.draftId, href: listingUrl
      });
    }
    // Native shell: let it capture authenticated + auto-close with a success
    // message. Harmless no-op in the browser extension (no bridge).
    try {
      if (nb) nb.onListingPublished("vinted", String(item.id), listingUrl || "");
    } catch (e) {}
    // Host hook (extension): the capture is done, drop its pending marker so no
    // later item page in another tab is reported for this draft.
    if (typeof o.onListingCaptured === "function") {
      try { o.onListingCaptured({ platform: "vinted", listingId: String(item.id), listingUrl: listingUrl }); } catch (e) {}
    }
  }

  // Stop watching the URL without a capture and tell the host (extension) to drop
  // its pending marker too.
  function endVintedWatch(w, reason) {
    if (!w || w.done) return;
    w.done = true;
    console.log("Velosia: Vinted-Erfassung beendet (" + reason + ")");
    if (typeof w.options.onCaptureAborted === "function") {
      try { w.options.onCaptureAborted({ platform: "vinted", reason: reason }); } catch (e) {}
    }
  }

  // A new autofill run on this page replaces the watch silently (the new run
  // resets the host marker itself); a late create response no longer counts.
  function supersedeVintedWatch() {
    var w = vintedWatch;
    if (!w) return;
    w.superseded = true;
    w.done = true;
  }

  // Patch fetch/XHR once per page; the patches report to the current watch.
  function installVintedNetWatch() {
    if (vintedNetPatched) return;
    vintedNetPatched = true;

    // Pull the new item out of the create response. id alone is enough here (we
    // only parse the known create endpoint, so a bare id is the listing id).
    function itemFromJson(data) {
      if (!data || typeof data !== "object") return null;
      var item = data.item || data;
      if (item && item.id != null) return item;
      return null;
    }

    // A POST/PUT to a Vinted /api/ path is a publish candidate (logged for
    // diagnosis). EXCLUDE our own backend calls (telemetry/listing capture) — they
    // go through the same patched fetch and must never be inspected as a publish.
    function isCandidate(w, url, method) {
      url = url || "";
      if (!/post|put/i.test(method || "") || !/\/api\//i.test(url)) return false;
      var backendUrl = w.options.backendUrl || "";
      if (backendUrl && url.indexOf(backendUrl) !== -1) return false;
      if (/\/api\/(telemetry|listings)\//i.test(url)) return false;
      return true;
    }

    // The watch to report to if this request is Vinted's create call, else null.
    // Once the URL watch has ended, only while a triggered publish is still valid
    // (Vinted may route away from the form before its create call goes out).
    function observe(method, url) {
      var w = vintedWatch;
      if (!w || w.captured || w.superseded) return null;
      if (w.done && !isPublishArmed(w.session)) return null;
      if (!isCandidate(w, url, method)) return null;
      console.log("Velosia: Vinted-Publish-Request beobachtet -> " + method + " " + url);
      if (!isVintedCreateRequest(url, method)) return null;
      // The create call itself is the publish action (also arms the URL backstop).
      if (publishSession && publishSession === w.session) armPublish("create-request");
      return w;
    }

    // --- Patch fetch: inspect the create call's response. ---
    try {
      var origFetch = window.fetch;
      if (origFetch && !origFetch.__velosiaPatched) {
        var patched = function (input, init) {
          var url = (typeof input === "string") ? input : (input && input.url) || (input ? String(input) : "");
          var method = (init && init.method) || (input && input.method) || "GET";
          var p = origFetch.apply(this, arguments);
          try {
            var w = observe(method, url);
            if (w) {
              p.then(function (resp) {
                if (!resp || !resp.ok) return;
                try {
                  resp.clone().json().then(function (data) {
                    var item = itemFromJson(data);
                    if (item) fireVintedCapture(w, item);
                  }).catch(function () {});
                } catch (e) {}
              }).catch(function () {});
            }
          } catch (e) {}
          return p;
        };
        patched.__velosiaPatched = true;
        window.fetch = patched;
      }
    } catch (e) {}

    // --- Patch XHR as a secondary path (in case Vinted uses XHR somewhere). ---
    try {
      var XHR = window.XMLHttpRequest;
      if (XHR && XHR.prototype && !XHR.prototype.__velosiaPatched) {
        var origOpen = XHR.prototype.open;
        var origSend = XHR.prototype.send;
        XHR.prototype.open = function (method, url) {
          this.__velosiaMethod = method; this.__velosiaUrl = url;
          return origOpen.apply(this, arguments);
        };
        XHR.prototype.send = function () {
          try {
            var self = this;
            var w = observe(self.__velosiaMethod, self.__velosiaUrl);
            if (w) {
              self.addEventListener("load", function () {
                try {
                  if (self.status < 200 || self.status >= 300) return;
                  var item = itemFromJson(JSON.parse(self.responseText));
                  if (item) fireVintedCapture(w, item);
                } catch (e) {}
              });
            }
          } catch (e) {}
          return origSend.apply(this, arguments);
        };
        XHR.prototype.__velosiaPatched = true;
      }
    } catch (e) {}
  }

  // Fire-and-forget (do not await). session = this page's publish session.
  async function watchVintedPublish(draft, options, session) {
    if (!draft || draft.id == null || !options || !options.backendUrl) return;
    supersedeVintedWatch();
    var w = {
      draftId: draft.id, options: options, session: session || null,
      formPath: window.location.pathname || "", done: false, captured: false, superseded: false
    };
    vintedWatch = w;
    try { installVintedNetWatch(); } catch (e) {}

    function onForm(path) {
      return path === w.formPath || /^\/items\/new(\/|$)/.test(path);
    }

    // Only the FIRST navigation away from the form decides: an item page reached
    // after the publish action -> capture; anything else (back/forward, catalog,
    // an item opened before publishing …) -> stop for good. Query/hash changes on
    // the form itself are ignored.
    function check(traversal) {
      if (w.done) return;
      if (onForm(window.location.pathname || "")) return;
      var info = parseListingUrl(window.location.href);
      if (!traversal && info && info.platform === "vinted" && isPublishArmed(w.session)) {
        fireVintedCapture(w, { id: info.listingId, url: info.listingUrl });
      } else {
        endVintedWatch(w, traversal ? "back/forward" : "left the form without publishing");
      }
    }
    function onPop() { check(true); }
    function onEntry(e) { check(!!(e && e.navigationType === "traverse")); }

    // popstate = back/forward. The Navigation API (where available) reports every
    // SPA route change right away; the poll is the fallback.
    var nav = null;
    try { nav = window.navigation || null; } catch (e) {}
    try { window.addEventListener("popstate", onPop, true); } catch (e) {}
    try { if (nav && nav.addEventListener) nav.addEventListener("currententrychange", onEntry); } catch (e) {}

    // Keep watching while the user reviews (up to an hour), longer only while a
    // triggered publish is still valid.
    var started = Date.now();
    while (!w.done) {
      await sleep(1000);
      check(false);
      if (!w.done && (Date.now() - started) > 60 * 60 * 1000 && !isPublishArmed(w.session)) {
        endVintedWatch(w, "timeout");
      }
    }
    try { window.removeEventListener("popstate", onPop, true); } catch (e) {}
    try { if (nav && nav.removeEventListener) nav.removeEventListener("currententrychange", onEntry); } catch (e) {}
  }

  // eBay keeps the URL at /lstng after publishing and only shows a dialog "Ihr
  // Angebot ist jetzt online" with a link "Angebot anzeigen" -> /itm/<id> (live
  // 2026-11). Watch for that link — only after the publish action was triggered.
  var ebayWatch = null;

  // Only the success dialog counts ("Ihr Angebot ist jetzt online"), and only its
  // "Angebot anzeigen" link: the form's price helpers and duplicate hints also
  // show /itm/ links — to other people's listings.
  function ebaySuccessLink() {
    var dialogs = document.querySelectorAll(".lightbox-dialog, [role='dialog'], dialog");
    for (var d = 0; d < dialogs.length; d++) {
      var text = norm(dialogs[d].innerText || dialogs[d].textContent || "");
      if (text.indexOf("jetzt online") === -1 && text.indexOf("wurde eingestellt") === -1) continue;
      var links = dialogs[d].querySelectorAll("a[href*='/itm/']");
      for (var i = 0; i < links.length; i++) {
        if (norm(links[i].innerText || links[i].textContent) !== "angebot anzeigen") continue;
        var info = parseListingUrl(links[i].href);
        if (info && info.platform === "ebay") return info;
      }
    }
    return null;
  }

  async function watchEbayPublish(draft, options, session) {
    if (!draft || draft.id == null) return;
    if (ebayWatch) ebayWatch.done = true;
    var w = { done: false };
    ebayWatch = w;
    var started = Date.now();
    while (!w.done) {
      await sleep(1000);
      if (w.done) break;
      if (isPublishArmed(session)) {
        var info = ebaySuccessLink();
        if (info) {
          w.done = true;
          console.log("Velosia: eBay-Angebot erkannt -> id=" + info.listingId);
          var nb = nativeBridge("onListingPublished");
          if (options.token || !nb) {
            captureListing({ backendUrl: options.backendUrl, token: options.token, draftId: draft.id, href: info.listingUrl });
          }
          try { if (nb) nb.onListingPublished("ebay", String(info.listingId), info.listingUrl); } catch (e) {}
          if (typeof options.onListingCaptured === "function") {
            try { options.onListingCaptured({ platform: "ebay", listingId: info.listingId, listingUrl: info.listingUrl }); } catch (e) {}
          }
          break;
        }
      }
      if ((Date.now() - started) > 60 * 60 * 1000 && !isPublishArmed(session)) {
        w.done = true;
        if (typeof options.onCaptureAborted === "function") {
          try { options.onCaptureAborted({ platform: "ebay", reason: "timeout" }); } catch (e) {}
        }
      }
    }
  }

  // ----------------------------------------------------------------------------
  // Public entry point
  // ----------------------------------------------------------------------------

  async function autofill(draft, options) {
    options = options || {};
    if (typeof draft === "string") {
      try { draft = JSON.parse(draft); } catch (e) { draft = {}; }
    }
    var platform = options.platform || detectPlatform();
    var phase = detectPhase(platform);
    // eBay is never published automatically: its form asks for more than we can
    // know (item specifics, shipping) — the user always reviews and submits.
    var autoSubmit = !!options.autoSubmit && platform !== "ebay";
    var showUi = options.showOverlay !== false;

    try {
      // Plain-string log (objects render as "[object Object]" in Android Logcat).
      console.log("Velosia engine v" + VERSION + " autofill: platform=" + platform +
        " phase=" + phase + " autoSubmit=" + autoSubmit +
        " imageMode=" + options.imageMode +
        " category=" + (draft && draft.category) + " category_path=" + (draft && draft.category_path) +
        " vinted_category=" + (draft && draft.vinted_category) + " vinted_path=" + (draft && draft.vinted_path));
    } catch (e) {}

    // A new run replaces this page's earlier publish session / Vinted watch, and the
    // engine's own clicks while filling must never count as the publish action.
    publishSession = null;
    supersedeVintedWatch();

    // Kleinanzeigen step 1: pick the category, then let the step-2 reload fill.
    // A light backdrop signals progress; the page reloads to schritt2 right after.
    if (platform === "kleinanzeigen" && phase === "category") {
      if (showUi) { ensureBackdrop(); setBackdrop("Kategorie wird gewählt …"); }
      var result0 = { platform: platform, phase: phase, filled: [], manual: [], photos: 0, submitted: false };
      var catOk;
      try { catOk = await autoSelectCategory(draft); }
      catch (e) { catOk = false; if (showUi) removeBackdrop(); }
      console.log("Velosia: Kategorie-Auswahl (KA) ->", catOk ? "Weiter geklickt" : "fehlgeschlagen/manuell", "path=", draft && draft.category_path);
      sendTelemetry({ platform: platform, phase: phase, category_ok: !!catOk }, options);
      // If "Weiter" did not fire we stay on this page — drop the backdrop so the
      // user can pick the category manually instead of being stuck behind it.
      if (showUi && !catOk) removeBackdrop();
      return result0;
    }

    // An eBay page that is not part of creating a new listing (revising a live
    // one, selling a similar item): nothing to fill there.
    if (platform === "ebay" && (phase === "other" || phase === "drafts")) {
      return { platform: platform, phase: phase, filled: [], manual: [], photos: 0, submitted: false };
    }

    // eBay before the form: title on the prelist page, then (wide layout) skip
    // the catalog product and pick the condition. Each step navigates on.
    if (platform === "ebay" && (phase === "prelist" || phase === "identify")) {
      if (showUi) {
        ensureBackdrop();
        setBackdrop(phase === "prelist" ? "Artikel wird angelegt …" : phase === "drafts" ? "Entwurf wird geöffnet …" : "Zustand wird gewählt …");
      }
      var resE = { platform: platform, phase: phase, filled: [], manual: [], photos: 0, submitted: false };
      var moved = false;
      try {
        if (phase === "prelist") moved = await ebayPrelist(draft);
        else {
          var idr = await ebayIdentify(draft);
          moved = idr.continued;
          sendTelemetry({ platform: platform, phase: phase, condition_ok: draft.condition ? idr.condition : undefined }, options);
        }
      } catch (e) { moved = false; }
      // If nothing moved on, let the user continue by hand instead of being stuck.
      if (showUi && !moved) removeBackdrop();
      // Watchdog: a click that "moved" but never navigated must not leave the
      // spinner up for good (the app runs each of these pages only once).
      if (showUi && moved) {
        var hereNow = window.location.href;
        setTimeout(function () { if (window.location.href === hereNow) removeBackdrop(); }, 15000);
      }
      return resE;
    }

    // Form phase: block the page behind a full-screen progress backdrop while the
    // engine fills the fields, then reveal the result + an arrow to "Veröffentlichen".
    if (showUi) ensureBackdrop();

    // Publish session for the listing capture: only a click on the publish button
    // (or auto-submit below) AFTER filling arms it — also when filling fails and the
    // user completes the form by hand.
    var session = startPublishSession(platform, draft, options);

    var r;
    try {
      r = await fillForm(draft, options, platform);
    } catch (e) {
      session.ready = true;
      if (showUi) removeBackdrop();
      throw e;
    }
    session.ready = true;
    var result = {
      platform: platform, phase: phase,
      filled: r.filled, manual: r.manual, photos: r.photos, submitted: false
    };

    var rf = r.fields || {};
    sendTelemetry({
      platform: platform, phase: phase,
      title_found: r.found ? r.found.title : null,
      description_found: r.found ? r.found.description : null,
      price_found: r.found ? r.found.price : null,
      category_ok: r.categoryOk,
      // Attribute pickers: undefined keys are dropped by JSON.stringify -> stored as
      // NULL (= "not attempted"), so the anomaly monitor only counts real attempts.
      condition_ok: rf.condition, size_ok: rf.size, color_ok: rf.color,
      material_ok: rf.material, brand_ok: rf.brand,
      photos: r.photos, attributes_count: r.attrCount
    }, options);

    // Vinted publishes via SPA navigation (no reload) — start watching for the
    // resulting /items/<id> URL so we can capture & track the listing. Works for
    // both manual and auto-submit. Fire-and-forget. (Kleinanzeigen reloads to a
    // fresh page, so its capture is handled by the host: the extension's content
    // scripts or the native shell.)
    if (platform === "vinted" && phase === "form") {
      try {
        var watching = watchVintedPublish(draft, options, session);
        if (watching && watching.catch) watching.catch(function () {});
      } catch (e) {}
    }
    if (platform === "ebay" && phase === "form") {
      try {
        var watchingE = watchEbayPublish(draft, options, session);
        if (watchingE && watchingE.catch) watchingE.catch(function () {});
      } catch (e) {}
    }

    if (autoSubmit) {
      // Keep the backdrop up and let image upload + framework state settle before
      // publishing automatically.
      if (showUi) setBackdrop("Wird veröffentlicht …");
      await sleep(3500);
      result.submitted = await trySubmit(platform);
      if (showUi) removeBackdrop();
    } else {
      // Manual mode: drop the blocking backdrop, show the "what was filled" panel
      // and point a tracking arrow at the publish button so the user knows to tap it.
      if (showUi) {
        removeBackdrop();
        showOverlay(result, autoSubmit);
        pointToButton(findSubmitButton(platform));
      }
    }
    return result;
  }

  // ── Delete a live ad on Kleinanzeigen ("Meine Anzeigen") ───────────────────
  // KA's public ad page has no delete control; its own-ads list does — one
  // <li data-adid="…"> per ad with a "Löschen" button that opens a confirm
  // <dialog aria-labelledby="delete-container-title"> ("Abbrechen" / "Ja, Anzeige
  // löschen"), checked live 2026-11. That list is a desktop layout in the WebView
  // (the button sits off to the right, the dialog half off-screen), so the app
  // calls this: it opens KA's dialog itself (opening deletes nothing), hides it
  // and shows the same question as a Velosia sheet in the visible viewport. The
  // deletion itself is only ever the user's tap on "Ja, löschen".
  function focusOwnListing(adId) {
    adId = String(adId || "").replace(/\D/g, "");
    if (!adId) return false;
    if (!document.getElementById("velosia-focus-style")) {
      var st = document.createElement("style");
      st.id = "velosia-focus-style";
      st.textContent =
        "@keyframes velosia-focus-pulse{0%,100%{box-shadow:0 0 0 3px rgba(239,68,68,.9)}50%{box-shadow:0 0 0 7px rgba(239,68,68,.35)}}" +
        "@keyframes velosia-sheet-up{from{transform:translateY(24px);opacity:0}to{transform:none;opacity:1}}" +
        "@keyframes velosia-spin{to{transform:rotate(360deg)}}" +
        "dialog.velosia-hosted::backdrop{background:rgba(3,5,8,.62)}";
      (document.head || document.documentElement).appendChild(st);
    }
    function visible(el) {
      var r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== "hidden";
    }
    function buttonNamed(root, re, anyVisibility) {
      var els = root.querySelectorAll("button, a");
      for (var i = 0; i < els.length; i++) {
        if (re.test((els[i].textContent || "").replace(/\s+/g, " ").trim()) && (anyVisibility || visible(els[i]))) return els[i];
      }
      return null;
    }
    function chip(text) {
      var old = document.getElementById("velosia-focus-chip");
      if (old) old.remove();
      var c = document.createElement("div");
      c.id = "velosia-focus-chip";
      c.textContent = text;
      c.style.cssText = "position:fixed;z-index:2147483646;max-width:86vw;padding:12px 18px;border-radius:14px;background:#10141c;color:#f8fafc;font:600 15px/1.35 -apple-system,BlinkMacSystemFont,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.45);border:1px solid rgba(9,176,183,.5);text-align:center";
      c.addEventListener("click", function () { c.remove(); });
      document.body.appendChild(c);
      var sync = bindViewport(function () {
        var r = viewportRect();
        c.style.left = (r.left + (r.width - c.offsetWidth) / 2) + "px";
        c.style.top = (r.top + r.height - c.offsetHeight - 24) + "px";
      });
      setTimeout(function () { unbindViewport(sync); if (c.parentNode) c.remove(); }, 7000);
    }
    function adTitle(row) {
      // The title is the row's <h3>; its text starts with a screen-reader-only
      // "Anzeige " (the first link is the photo, whose text is the photo count).
      var t = row.querySelector("h3") || row.querySelector("h2");
      return t ? (t.textContent || "").replace(/\s+/g, " ").trim().replace(/^Anzeige\s+/, "").slice(0, 90) : "";
    }
    function findDialog() {
      var d = document.querySelector('dialog[aria-labelledby="delete-container-title"]');
      if (d && (d.open || d.hasAttribute("open"))) return d;
      var all = document.querySelectorAll("dialog[open], [role='dialog'][aria-modal='true']");
      for (var i = 0; i < all.length; i++) {
        if (buttonNamed(all[i], /ja.*löschen/i, true)) return all[i];
      }
      return null;
    }
    function goBack() {
      try { if (window.VelosiaBridge && window.VelosiaBridge.reloadApp) { window.VelosiaBridge.reloadApp(); return; } } catch (e) {}
      try { history.back(); } catch (e) {}
    }
    function btnCss(kind) {
      var base = "flex:1;min-height:50px;border-radius:13px;font:700 16px/1 -apple-system,BlinkMacSystemFont,sans-serif;cursor:pointer;";
      if (kind === "danger") return base + "border:none;background:#ef4444;color:#fff;";
      if (kind === "primary") return base + "border:none;background:#09b0b7;color:#031314;";
      return base + "border:1px solid rgba(255,255,255,.14);background:transparent;color:#e2e8f0;";
    }

    // Success signals after "Ja, Anzeige löschen": the delete request answering
    // 2xx (fetch/XHR naming the ad id), a "gelöscht" notice, or (above) the row
    // leaving or the page navigating.
    function watchDeleteSuccess(id, done) {
      function hit(url, method, body) {
        var u = String(url || ""), b = typeof body === "string" ? body : "";
        return (u.indexOf(id) >= 0 || b.indexOf(id) >= 0) && /^(post|delete|put)$/i.test(method || "get");
      }
      try {
        var of = window.fetch;
        if (of && !of.__velosiaWrapped) {
          var wrapped = function (input, init) {
            var url = typeof input === "string" ? input : (input && input.url);
            var method = (init && init.method) || (input && input.method) || "GET";
            var watch = hit(url, method, init && init.body);
            return of.apply(this, arguments).then(function (res) {
              if (watch && res && res.ok) setTimeout(done, 300);
              return res;
            });
          };
          wrapped.__velosiaWrapped = true;
          window.fetch = wrapped;
        }
      } catch (e) {}
      try {
        var XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
        if (!XO.__velosiaWrapped) {
          XMLHttpRequest.prototype.open = function (m, u) { this.__vMethod = m; this.__vUrl = u; return XO.apply(this, arguments); };
          XMLHttpRequest.prototype.open.__velosiaWrapped = true;
          XMLHttpRequest.prototype.send = function (body) {
            var x = this;
            if (hit(x.__vUrl, x.__vMethod, body)) {
              x.addEventListener("load", function () { if (x.status >= 200 && x.status < 300) setTimeout(done, 300); });
            }
            return XS.apply(this, arguments);
          };
        }
      } catch (e) {}
    }
    function successNotice() {
      var els = document.querySelectorAll("[role='status'], [role='alert'], [class*='toast'], [class*='notification'], [class*='snackbar']");
      for (var i = 0; i < els.length; i++) {
        if (/gelöscht/i.test(els[i].textContent || "") && visible(els[i])) return true;
      }
      return false;
    }
    function otherOpenDialog(mine) {
      var all = document.querySelectorAll("dialog[open], [role='dialog'][aria-modal='true']");
      for (var i = 0; i < all.length; i++) {
        if (all[i] !== mine && !mine.contains(all[i]) && visible(all[i])) return all[i];
      }
      return null;
    }

    // Velosia's own confirm sheet, hosted INSIDE KA's (possibly modal) dialog so it
    // stays tappable, anchored to the visible viewport.
    function showSheet(dialog, row) {
      var kids = dialog.children;
      for (var i = 0; i < kids.length; i++) kids[i].style.visibility = "hidden";
      dialog.classList.add("velosia-hosted");
      dialog.style.background = "rgba(3,5,8,.62)";
      dialog.style.border = "none";
      dialog.style.boxShadow = "none";

      var sheet = document.createElement("div");
      sheet.id = "velosia-delete-sheet";
      sheet.style.cssText = "position:fixed;z-index:2147483646;box-sizing:border-box;padding:20px 18px 18px;border-radius:22px;background:#10141c;border:1px solid rgba(255,255,255,.12);box-shadow:0 18px 50px rgba(0,0,0,.6);color:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,sans-serif;animation:velosia-sheet-up .22s ease-out;visibility:visible";
      dialog.appendChild(sheet);
      var title = adTitle(row);
      function render(state) {
        if (state === "ask") {
          sheet.innerHTML =
            '<div style="font-size:19px;font-weight:700;margin-bottom:6px">Anzeige löschen?</div>' +
            (title ? '<div style="font-size:14px;color:#94a3b8;line-height:1.4;margin-bottom:18px" id="velosia-del-title"></div>' : '<div style="height:12px"></div>') +
            '<div style="display:flex;gap:10px"><button id="velosia-del-no" style="' + btnCss() + '">Abbrechen</button>' +
            '<button id="velosia-del-yes" style="' + btnCss("danger") + '">Ja, löschen</button></div>';
          if (title) sheet.querySelector("#velosia-del-title").textContent = title;
          sheet.querySelector("#velosia-del-no").addEventListener("click", cancel);
          sheet.querySelector("#velosia-del-yes").addEventListener("click", confirm);
        } else if (state === "busy") {
          sheet.innerHTML = '<div style="display:flex;align-items:center;gap:12px;font-size:16px;font-weight:600;padding:6px 0">' +
            '<span style="width:20px;height:20px;border-radius:50%;border:3px solid rgba(9,176,183,.25);border-top-color:#09b0b7;animation:velosia-spin .8s linear infinite"></span>Wird gelöscht …</div>';
        } else if (state === "done") {
          sheet.innerHTML = '<div style="font-size:19px;font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:10px">' +
            '<span style="width:28px;height:28px;border-radius:50%;background:#34d399;color:#04140d;display:inline-flex;align-items:center;justify-content:center;font-size:16px">✓</span>Gelöscht</div>' +
            '<div style="display:flex"><button id="velosia-del-back" style="' + btnCss("primary") + '">Zurück zu Velosia</button></div>';
          sheet.querySelector("#velosia-del-back").addEventListener("click", goBack);
        }
      }
      var sync = bindViewport(function () {
        if (!sheet.isConnected) return;
        var r = viewportRect();
        var w = Math.min(r.width - 24, 460);
        sheet.style.width = w + "px";
        sheet.style.left = (r.left + (r.width - w) / 2) + "px";
        sheet.style.top = (r.top + r.height - sheet.offsetHeight - 16) + "px";
      });
      function teardown() {
        unbindViewport(sync);
        if (sheet.parentNode) sheet.remove();
        for (var i = 0; i < kids.length; i++) kids[i].style.visibility = "";
        dialog.classList.remove("velosia-hosted");
        dialog.style.background = dialog.style.border = dialog.style.boxShadow = "";
      }
      function cancel() {
        var no = buttonNamed(dialog, /^abbrechen$/i, true) || buttonNamed(dialog, /^schließen$/i, true);
        teardown();
        if (no) no.click();
      }
      function confirm() {
        var yes = buttonNamed(dialog, /ja.*löschen/i, true);
        if (!yes) { teardown(); chip("Tippe auf „Ja, Anzeige löschen“."); return; }
        render("busy");
        sync();
        var finished = false;
        function success() {
          if (finished) return;
          finished = true;
          var open = dialog.isConnected && (dialog.open || dialog.hasAttribute("open"));
          (open ? dialog : document.body).appendChild(sheet);
          render("done");
          sync();
          // Back to the draft in Velosia on its own; the button stays as a fallback.
          setTimeout(goBack, 1100);
        }
        watchDeleteSuccess(adId, success);
        // KA may reload the page after deleting: that navigation is the success.
        window.addEventListener("pagehide", function () { if (!finished) { finished = true; goBack(); } });
        yes.click();
        var n = 0;
        (function wait() {
          if (finished) return;
          var row = document.querySelector('li[data-adid="' + adId + '"]');
          if (!row || /gelöscht/i.test(row.textContent || "") || successNotice()) return success();
          // KA asks something else first (another dialog): step aside so the user
          // can answer it; success is still caught and brings them back.
          var other = otherOpenDialog(dialog);
          if (other && sheet.isConnected && sheet.textContent.indexOf("Wird gelöscht") >= 0) teardownSheetOnly();
          if (++n < 60) return setTimeout(wait, 250);
          teardown();
          chip("Bitte prüfe, ob die Anzeige gelöscht ist.");
        })();
      }
      function teardownSheetOnly() {
        unbindViewport(sync);
        if (sheet.parentNode) sheet.remove();
      }
      render("ask");
      sync();
      requestAnimationFrame(sync);
    }

    var tries = 0;
    (function look() {
      var row = document.querySelector('li[data-adid="' + adId + '"]');
      if (!row) {
        if (++tries < 40) return setTimeout(look, 250);
        chip("Anzeige nicht gefunden – vielleicht ist sie schon gelöscht.");
        return;
      }
      var del = buttonNamed(row, /^löschen$/i, true);
      if (!del) {
        // Layout changed: fall back to pointing at the row.
        row.style.outline = "3px solid #09b0b7";
        row.style.outlineOffset = "4px";
        var more = buttonNamed(row, /^mehr$/i);
        if (more) more.style.animation = "velosia-focus-pulse 1.3s ease-in-out infinite";
        row.scrollIntoView({ block: "center", inline: "center" });
        chip(more ? "Tippe auf „Mehr“ und dann auf „Löschen“." : "Lösch die markierte Anzeige.");
        return;
      }
      del.click(); // opens KA's confirm dialog — nothing is deleted yet
      var waits = 0;
      (function awaitDialog() {
        var dialog = findDialog();
        if (dialog) return showSheet(dialog, row);
        if (++waits < 16) return setTimeout(awaitDialog, 200);
        // No dialog: point at the button instead.
        del.style.animation = "velosia-focus-pulse 1.3s ease-in-out infinite";
        del.scrollIntoView({ block: "center", inline: "center" });
        chip("Tippe auf „Löschen“.");
      })();
    })();
    return true;
  }

  window.__velosia = {
    __loaded: true,
    focusOwnListing: focusOwnListing,
    version: VERSION,
    autofill: autofill,
    detectPlatform: detectPlatform,
    detectPhase: detectPhase,
    parseListingUrl: parseListingUrl,
    captureListing: captureListing
  };
})();
