let backendUrl = "https://api.velosia.henrikheil.net"; // Default to production

// Identifies API requests made by the extension (version from the manifest).
const CLIENT_HEADER = { "X-Velosia-Client": "ext/" + chrome.runtime.getManifest().version };

function authHeaders(token) {
  return Object.assign({ "Authorization": `Bearer ${token}` }, CLIENT_HEADER);
}

document.addEventListener("DOMContentLoaded", async () => {
  const statusBadge = document.getElementById("status");
  const loginView = document.getElementById("login-view");
  const connectedView = document.getElementById("connected-view");
  const loginForm = document.getElementById("login-form");
  const logoutBtn = document.getElementById("logout-btn");
  const userEmailSpan = document.getElementById("user-email");
  const errorMsgDiv = document.getElementById("error-message");
  const envSelect = document.getElementById("env-select");
  const dashboardBtn = document.getElementById("btn-open-dashboard");

  // Load backend URL and check storage for existing token
  chrome.storage.local.get(["velosia_token", "velosia_user_email", "velosia_backend_url"], async (result) => {
    // Determine initially selected backend URL
    if (result.velosia_backend_url) {
      backendUrl = result.velosia_backend_url;
      envSelect.value = backendUrl.includes("localhost") ? "local" : "production";
    } else {
      backendUrl = "https://api.velosia.henrikheil.net";
      envSelect.value = "production";
      chrome.storage.local.set({ "velosia_backend_url": backendUrl });
    }

    updateDashboardLink();

    const token = result.velosia_token;
    if (token) {
      validateToken(token, result.velosia_user_email);
    } else {
      showLogin();
    }
  });

  // Handle environment change
  envSelect.addEventListener("change", () => {
    const selected = envSelect.value;
    backendUrl = selected === "local" ? "http://localhost:8000" : "https://api.velosia.henrikheil.net";
    
    updateDashboardLink();

    chrome.storage.local.set({ "velosia_backend_url": backendUrl }, () => {
      // Re-validate token under new environment
      chrome.storage.local.get(["velosia_token", "velosia_user_email"], (result) => {
        const token = result.velosia_token;
        if (token) {
          validateToken(token, result.velosia_user_email);
        } else {
          showLogin();
        }
      });
    });
  });

  // Update dashboard link dynamically
  function updateDashboardLink() {
    if (dashboardBtn) {
      dashboardBtn.href = backendUrl.includes("localhost") ? "http://localhost:5173" : "https://velosia.henrikheil.net";
    }
  }

  // Validate token with selected backend
  async function validateToken(token, savedEmail) {
    try {
      statusBadge.textContent = "Verbinde...";
      statusBadge.className = "status-badge disconnected";

      const response = await fetch(`${backendUrl}/api/auth/me`, {
        headers: authHeaders(token)
      });
      
      if (response.ok) {
        const user = await response.json();
        showConnected(user.email);
      } else {
        // Token expired or invalid on this backend
        showLogin();
      }
    } catch (err) {
      // Server offline/unreachable
      showConnected(savedEmail || "Lokal angemeldet");
      statusBadge.textContent = "Offline (Backend)";
      statusBadge.className = "status-badge disconnected";
    }
  }

  // Handle Login Submit
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    errorMsgDiv.style.display = "none";

    try {
      const response = await fetch(`${backendUrl}/api/auth/login`, {
        method: "POST",
        headers: Object.assign({ "Content-Type": "application/json" }, CLIENT_HEADER),
        body: JSON.stringify({ email, password })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.detail || "Login fehlgeschlagen.");
      }

      const data = await response.json();
      const token = data.access_token;

      // Save token in storage
      chrome.storage.local.set({ 
        "velosia_token": token,
        "velosia_user_email": email
      }, () => {
        showConnected(email);
      });

    } catch (err) {
      errorMsgDiv.textContent = err.message;
      errorMsgDiv.style.display = "block";
    }
  });

  // Handle Logout
  logoutBtn.addEventListener("click", () => {
    chrome.storage.local.remove(["velosia_token", "velosia_user_email"], () => {
      showLogin();
    });
  });

  function showConnected(email) {
    statusBadge.textContent = "Verbunden";
    statusBadge.className = "status-badge connected";
    loginView.style.display = "none";
    connectedView.style.display = "block";
    userEmailSpan.textContent = email;
    loadDrafts();
  }

  function showLogin() {
    statusBadge.textContent = "Nicht angemeldet";
    statusBadge.className = "status-badge disconnected";
    loginView.style.display = "block";
    connectedView.style.display = "none";
    userEmailSpan.textContent = "";
  }
});

// ---------------------------------------------------------------------------
// Draft list + "launch straight onto a platform" flow
// ---------------------------------------------------------------------------

// eBay is offered only when switched on in the Velosia settings (V2.8).
let ebayEnabled = false;

// Load the user's drafts and initialise the auto-submit toggle from their saved
// profile preference, so an offer can be launched onto a platform in one click.
async function loadDrafts() {
  const listEl = document.getElementById("draft-list");
  const statusEl = document.getElementById("draft-list-status");
  const autoToggle = document.getElementById("auto-submit-toggle");
  if (!listEl) return;

  chrome.storage.local.get("velosia_token", async (data) => {
    const token = data.velosia_token;
    if (!token) return;

    try {
      const meRes = await fetch(`${backendUrl}/api/auth/me`, {
        headers: authHeaders(token)
      });
      if (meRes.ok) {
        const me = await meRes.json();
        if (autoToggle) autoToggle.checked = !!me.auto_submit;
        ebayEnabled = !!me.ebay_enabled;
      }
    } catch (e) { /* toggle just defaults to off */ }

    try {
      const res = await fetch(`${backendUrl}/api/drafts`, {
        headers: authHeaders(token)
      });
      if (!res.ok) throw new Error();
      renderDrafts(await res.json());
    } catch (e) {
      if (statusEl) statusEl.textContent = "Angebote konnten nicht geladen werden.";
    }
  });
}

function renderDrafts(drafts) {
  const listEl = document.getElementById("draft-list");
  const statusEl = document.getElementById("draft-list-status");
  if (!listEl) return;
  listEl.innerHTML = "";

  if (!drafts || drafts.length === 0) {
    if (statusEl) statusEl.textContent = "Noch keine Angebote. Fotografiere zuerst ein Teil im Dashboard.";
    return;
  }
  if (statusEl) statusEl.textContent = `${drafts.length} ${drafts.length === 1 ? "Angebot" : "Angebote"}:`;

  drafts.forEach((draft) => {
    const card = document.createElement("div");
    card.style.cssText = "background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.07); border-radius:8px; padding:8px; display:flex; gap:8px; align-items:center;";

    const img = document.createElement("img");
    img.style.cssText = "width:40px; height:40px; object-fit:cover; border-radius:5px; background:#000; flex-shrink:0;";
    img.alt = "";
    const imageUrl = draftImageUrl(draft.image_path);
    if (imageUrl) img.src = imageUrl;

    const info = document.createElement("div");
    info.style.cssText = "flex-grow:1; min-width:0;";
    const title = document.createElement("div");
    title.style.cssText = "font-size:12px; font-weight:600; color:#f8fafc; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;";
    title.textContent = draft.title || "Unbenannt";
    const price = document.createElement("div");
    price.style.cssText = "font-size:11px; color:#09b0b7; font-weight:bold;";
    price.textContent = draft.price != null && Number.isFinite(Number(draft.price))
      ? Math.round(Number(draft.price)) + " €"
      : "";
    info.appendChild(title);
    info.appendChild(price);

    const actions = document.createElement("div");
    actions.style.cssText = "display:flex; flex-direction:column; gap:4px; flex-shrink:0;";
    const draftId = Number(draft.id);
    [
      { platform: "vinted", label: "Vinted", style: "background:#09b0b7; color:#000; border:none;" },
      { platform: "kleinanzeigen", label: "Kleinanz.", style: "background:rgba(255,255,255,0.08); color:#f8fafc; border:1px solid rgba(255,255,255,0.12);" },
      ...(ebayEnabled ? [{ platform: "ebay", label: "eBay", style: "background:rgba(255,255,255,0.08); color:#f8fafc; border:1px solid rgba(255,255,255,0.12);" }] : [])
    ].forEach((p) => {
      const btn = document.createElement("button");
      btn.className = "velosia-launch";
      btn.textContent = p.label;
      btn.style.cssText = p.style + " border-radius:5px; font-size:10px; font-weight:bold; padding:4px 8px; cursor:pointer; white-space:nowrap;";
      btn.addEventListener("click", () => {
        if (Number.isInteger(draftId)) startAutofill(draftId, p.platform);
      });
      actions.appendChild(btn);
    });

    card.appendChild(img);
    card.appendChild(info);
    card.appendChild(actions);
    listEl.appendChild(card);
  });

}

// Queue the draft for autofill, then open the platform's "new listing" page in a
// new tab. The content script there reads the queued draft and fills the form.
function startAutofill(draftId, platform) {
  const autoToggle = document.getElementById("auto-submit-toggle");
  const autoSubmit = !!(autoToggle && autoToggle.checked);
  chrome.storage.local.set({
    velosia_pending_autofill: { draftId: draftId, platform: platform, autoSubmit: autoSubmit, createdAt: Date.now() }
  }, () => {
    const url = {
      vinted: "https://www.vinted.de/items/new",
      kleinanzeigen: "https://www.kleinanzeigen.de/p-anzeige-aufgeben.html",
      ebay: "https://www.ebay.de/sl/prelist/suggest"
    }[platform];
    chrome.tabs.create({ url: url });
    window.close();
  });
}

// Resolve a draft image path to an absolute URL on our backend's /uploads.
// Anything else (foreign hosts, other schemes) is not rendered.
function draftImageUrl(path) {
  if (!path || typeof path !== "string") return "";
  const prefix = `${backendUrl}/uploads/`;
  if (path.startsWith("/uploads/")) return `${backendUrl}${path}`;
  if (path.startsWith(prefix)) return path;
  return "";
}
